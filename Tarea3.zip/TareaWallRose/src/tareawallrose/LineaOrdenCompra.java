/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tareawallrose;

/**
 *
 * @author ericka
 */
public class LineaOrdenCompra {
    private float cantidad;
    private Producto producto;
    
    public LineaOrdenCompra(float cantidad, Producto producto) {
        this.cantidad = cantidad;
        this.producto = producto;
    }
    //Setters y Getters
    public void setCantidad(float cantidad){
        this.cantidad = cantidad;
    }
    public float getCantidad() {
        return cantidad;
    }
    public void setProducto(Producto producto) {
        this.producto = producto;
    }
    public Producto getProducto() {
        return producto;
    }
    
    public float calcularCosto() {
        return producto.getPrecio() * cantidad;
    }
    @Override
    public String toString() {
        String resultado;
        resultado = cantidad + "\t\t\t";
        resultado += producto.getNombre() + "\n";
        return resultado;
    }
}
