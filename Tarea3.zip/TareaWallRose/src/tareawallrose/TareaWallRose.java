/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tareawallrose;

import java.util.Scanner;

/**
 *
 * @author erick
 */
public class TareaWallRose {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
        try{
            System.out.println("Tarea 3 - Wall Rose");
            System.out.println("Debe crearse un pequeño programa de prueba que cree" +
                    "clientes, productos, órdenes de compra y las imprima en pantalla.\n");
            WallRose control = new WallRose();
            Scanner in = new Scanner(System.in);
            
            //Clientes
            control.agregarCliente("Cliente 1", "Email Cliente 1");
            control.agregarCliente("Cliente 2", "Email Cliente 2");
            control.agregarCliente("Cliente 3", "Email Cliente 3");
            //Productos
            control.crearProducto("Manzanas", 9.99f, "$", 65);
            control.crearProducto("Peras", 9.99f, "$", 65);
            control.crearProducto("Bananos", 9.99f, "$", 65);
            //Ordenes
            control.crearOrden(1);
            control.crearOrden(2);
            control.crearOrden(3);
            //Orden 1
            control.agregarLineaOrden(1, 1, 5);
            control.agregarLineaOrden(1, 2, 5);
            control.agregarLineaOrden(1, 3, 5);
            control.completarOrden(1);
            //Orden 2
            control.agregarLineaOrden(2, 1, 5);
            control.agregarLineaOrden(2, 2, 5);
            control.agregarLineaOrden(2, 3, 5);
            control.setOrdenPendiente(2);
            //Orden 3
            control.agregarLineaOrden(3, 1, 5);
            control.agregarLineaOrden(3, 2, 5);
            control.agregarLineaOrden(3, 3, 5);
            
            System.out.println("Instancias ya creadas:");
            System.out.println("Clientes");
            System.out.println( control.verListaClientes() );
            System.out.println("Órdenes");
            System.out.println( control.verListaOrdenes() );
            System.out.println("Productos");
            System.out.println( control.verListaProductos() );
    /*
    ----------------------------------------------------------------------------
    --------------------------CLIENTES------------------------------------------
    ----------------------------------------------------------------------------
    */
            System.out.println("\nFunciones de la clase Cliente\n");
            System.out.println("a. Ver lista de clientes");
            System.out.println("Se muestra una lista con todos los clientes registrados en el sistema.\n" +
                    "Se muestra número, nombre y email.");
            System.out.println( control.verListaClientes() );
            System.out.println("\nb. Agregar cliente");
            System.out.println("Se pide al usuario que escriba un nombre y un email.\n" +
                "Se crea un cliente nuevo y se guarda en la lista de clientes.");
            System.out.println("Ingrese el nombre del cliente");
            String nombre = in.nextLine();
            System.out.println("Ingrese el email del cliente");
            String email = in.nextLine();
            control.agregarCliente(nombre, email);
            System.out.println("Clientes");
            System.out.println( control.verListaClientes() );
            System.out.println("\nc. Ver todas las órdenes\n" +
    "Primero se muestra la lista de los clientes registrados en el sistema para que el usuario vea el\n" +
    "número de cada uno. Luego se pide al usuario que escriba un código de cliente. Si el código es\n" +
    "válido, se muestra en pantalla la lista de todas las órdenes asociadas al cliente elegido. Para\n" +
    "cada orden se muestra número, fecha, estado, líneas que la conforman, costo, monto por\n" +
    "impuesto y total. Si el código no es válido, se muestra un mensaje de error.");
            System.out.println( control.verListaClientes() );
            System.out.println("Ingrese un código de cliente");
            int a = in.nextInt();
            System.out.println("Todas las órdenes del cliente " + a);
            System.out.println( control.obtenerOrdenesClienteTodas(a) );
            System.out.println("\nd. Ver órdenes iniciadas\n" +
    "Similar a la opción anterior, pero la lista sólo contiene órdenes que se encuentran en estado\n" +
    "iniciado.");
            System.out.println( control.verListaClientes() );
            System.out.println("Ingrese un código de cliente");
            a = in.nextInt();
            System.out.println("Todas las órdenes iniciadas del cliente " + a);
            System.out.println( control.obtenerOrdenesClienteIniciadas(a) );
            System.out.println("\ne. Ver órdenes pendientes de pago\n" +
    "Similar a la opción anterior, pero la lista sólo contiene órdenes que se encuentran en estado\n" +
    "pendiente de pago.");
            System.out.println( control.verListaClientes() );
            System.out.println("Ingrese un código de cliente");
            a = in.nextInt();
            System.out.println("Todas las órdenes pendientes del cliente " + a);
            System.out.println( control.obtenerOrdenesClientePendientes(a) );
            System.out.println("\nf. Ver órdenes completadas\n" +
    "Similar a la opción anterior, pero la lista sólo contiene órdenes que se encuentran en estado\n" +
    "completada.");
            System.out.println( control.verListaClientes() );
            System.out.println("Ingrese un código de cliente");
            a = in.nextInt();
            System.out.println("Todas las órdenes completadas del cliente " + a);
            System.out.println( control.obtenerOrdenesClienteCompletadas(a) );
            System.out.println("\ng. Calcular total pendiente de un cliente\n" +
    "Se suma el costo de todas las órdenes");
            System.out.println( control.verListaClientes() );
            System.out.println("Ingrese un código de cliente");
            a = in.nextInt();
            System.out.println("Total pendiente del cliente " + a);
            System.out.println( control.calcularTotalPendienteCliente(a) );
                /*
    ----------------------------------------------------------------------------
    ---------------------ORDENES DE COMPRA--------------------------------------
    ----------------------------------------------------------------------------
    */
            System.out.println("\nFunciones de la clase Orden de Compra\n");
            System.out.println("a. Ver lista de órdenes de compra\n" +
"Se muestra una lista con todas las órdenes que existen en el sistema. Por cada orden se\n" +
"muestra número, fecha y estado.");
            System.out.println( control.verListaOrdenes() );
            System.out.println("\nb. Crear nueva órden de compra\n" +
"Primero se muestra una lista con todos los clientes registrados para que el usuario vea el\n" +
"número de cada uno. Luego se pide que escriba el número de cliente al que se le quiere crear la\n" +
"orden de compra. Si el número de cliente es válido se crea una nueva orden de compra vacía, se\n" +
"agrega a la lista de órdenes de compra y se muestra un mensaje que indica que se creó\n" +
"correctamente y el número de la orden creada. Si el número de cliente no es válido, se muestra\n" +
"un mensaje de error.");
            System.out.println( control.verListaClientes() );
            System.out.println("Ingrese un código de cliente");
            a = in.nextInt();
            control.crearOrden(a);
            System.out.println("Órdenes");
            System.out.println( control.verListaOrdenes() );
            System.out.println("\nc. Agregar línea a una orden de compra\n" +
"Se muestra en pantalla una lista con todas las órdenes registradas en el sistema para que el\n" +
"usuario vea el número de cada una. Luego se pide al usuario que escriba un número de orden.\n" +
"Si el número de orden es válido, se muestra una lista con todos los productos registrados en el\n" +
"sistema para que el usuario vea el código de cada uno, se pide al usuario que escriba un código\n" +
"de producto y luego la cantidad de ese producto para agregar la línea en dicha orden de\n" +
"compra. Se debe restar de las existencias del producto la cantidad agregada en la línea.\n" +
"Sí el número de orden o el código del producto no es válido, se muestra un mensaje de error y\n" +
"se regresa al menú de órdenes de compra.");
            System.out.println( control.verListaOrdenes() );
            System.out.println("Ingrese un número de orden");
            a = in.nextInt();
            control.verOrden(a);
            System.out.println( control.verListaProductos() );
            System.out.println("Ingrese un código de producto");
            int b = in.nextInt();
            control.verProducto(b);
            System.out.println("Ingrese la cantidad de ese producto");
            int c = in.nextInt();
            control.agregarLineaOrden(a, b, c);
            System.out.println("Orden de compra");
            System.out.println( control.verOrden(a) );
            System.out.println("\nd. Borrar línea de una orden de compra\n" +
"Se muestra en pantalla una lista con todas las órdenes registradas en el sistema para que el\n" +
"usuario vea el número de cada una. Luego se pide al usuario que escriba el número de orden. Si\n" +
"el número de orden es válido, se muestra la orden completa con todos sus detalles y líneas.\n" +
"Luego se pide al usuario que escriba el número de línea que desea borrar y se elimina de la\n" +
"orden de compra. Se debe sumar a las existencias del producto la cantidad de la línea borrada.\n" +
"Si el número de orden de compra o el número de línea es incorrecto, se muestra un mensaje de\n" +
"error.");
            System.out.println( control.verListaOrdenes() );
            System.out.println("Ingrese un número de orden");
            a = in.nextInt();
            control.verOrden(a);
            System.out.println( control.verOrden(a) );
            System.out.println("Ingrese el número de línea que desea borrar");
            b = in.nextInt();
            control.eliminarLineaOrden(a, b);
            System.out.println("Orden de compra");
            System.out.println( control.verOrden(a) );
            System.out.println("\ne. Calcular total pendiente\n" +
"Al utilizar esta opción se muestra la suma del total de todas las órdenes que están marcadas\n" +
"como pendientes de pago. Sirve para saber cuánto dinero se le debe a la tienda en total.");
            System.out.println( control.calcularTotalPendiente() );
            
            /*
    ----------------------------------------------------------------------------
    --------------------------PRODUCTOS-----------------------------------------
    ----------------------------------------------------------------------------
    */
            System.out.println("\nFunciones de la clase Producto\n");
            System.out.println("a. Ver lista de productos\n" +
"Muestra una lista con todos los productos registrados en el sistema. Por cada producto debe\n" +
"mostrarse código, nombre, cantidad en existencias, unidad de medida y precio.");
            System.out.println( control.verListaProductos() );
            System.out.println("\nb. Agregar producto\n" +
"Se pregunta al usuario que escriba nombre, precio, unidad de medida y cantidad inicial en\n" +
"existencias. Se crea el producto y se guarda en la lista de productos.");
            System.out.println("Ingrese el nombre del producto");
            in.nextLine();
            String Nombre = in.nextLine();
            System.out.println("Nombre: " + Nombre);
            System.out.println("Ingrese el precio del producto");
            float precio = in.nextFloat();
            System.out.println("Precio: " + precio);
            System.out.println("Ingrese la unidad del producto");
            in.nextLine();
            String unidad = in.nextLine();
            System.out.println("Unidad: " + unidad);
            System.out.println("Ingrese las existencias del producto");
            float existencias = in.nextFloat();
            System.out.println("Existencias: " + existencias);
            control.crearProducto(Nombre, precio, unidad, existencias);
            System.out.println( control.verListaProductos() );
            System.out.println("\nc. Agregar existencias\n" +
"En esta opción el usuario puede agregar existencias al producto. Se muestra la lista de todos los\n" +
"productos para que el usuario vea el código de cada uno. Luego se lee el código del producto\n" +
"para agregar existencias. Si el código es válido, se pide que escriba la cantidad de existencias\n" +
"que desea agregar. Si el código no es válido, se muestra un mensaje de error.");
            System.out.println( control.verListaProductos() );
            System.out.println("Ingrese el código del producto");
            a = in.nextInt();
            control.verProducto(a);
            System.out.println( control.verProducto(a) );
            System.out.println("Ingrese la cantidad de existencias");
            existencias = in.nextFloat();
            control.agregarExistenciasProducto(a, existencias);
            System.out.println( control.verProducto(a) );
        }
        catch (Exception ex) {
            System.out.println( ex.toString() );
        }
    }
}
