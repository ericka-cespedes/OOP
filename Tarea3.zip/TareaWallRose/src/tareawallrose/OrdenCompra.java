/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tareawallrose;

import java.time.LocalDateTime;
import java.util.ArrayList;

/**
 *
 * @author ericka
 */
public class OrdenCompra {
    public static int consecutivo = 1;
    public static float IV = 0.13f;
    private int numero;
    private LocalDateTime fechaHora;
    private Cliente cliente;
    private ArrayList<LineaOrdenCompra> lineas;
    private EstadoCompra estado;
    
    public OrdenCompra(Cliente cliente) {
        this.cliente = cliente;
        this.numero = consecutivo;
        consecutivo++;
        fechaHora = LocalDateTime.now();
        lineas = new ArrayList();
        estado = EstadoCompra.INICIADA;
    }
    //Setters y Getters
    public void setNumero(int numero) {
        this.numero = numero;
    }
    public int getNumero() {
        return numero;
    }
    public void setFechaHora(LocalDateTime fechaHora) {
        this.fechaHora = fechaHora;
    }
    public LocalDateTime getFechaHora() {
        return fechaHora;
    }
    public void setEstado(EstadoCompra estado) {
        this.estado = estado;
    }
    public EstadoCompra getEstado() {
        return estado;
    }
    public LineaOrdenCompra getLinea(int pos){
        LineaOrdenCompra linea = lineas.get(pos);
        return linea;
    }
    
    //Agregar y borrar lineas
    public void agregarLinea(float cantidad, Producto producto) {
        lineas.add(new LineaOrdenCompra(cantidad, producto));
    }
    public void borrarLinea(int pos) {
        lineas.remove(pos);
    }
    
    public float calcularCosto() {
        //Revisar
        float resultado = 0;
        for (LineaOrdenCompra linea : lineas) {
            resultado += linea.calcularCosto();
        }
        return resultado;
    }
    public float calcularImpuesto() {
        return calcularCosto() * IV;
    }
    public float calcularTotal() {
        return calcularCosto() + calcularImpuesto();
    }
    @Override
    /*
    Para cada orden se muestra número, fecha, estado, líneas que la conforman,
    costo, monto por impuesto y total.
    */
    public String toString() {
        String resultado;
        resultado = "Número de orden: " + numero + "\t\t\t";
        resultado += "Fecha: " + fechaHora + "\t\t\t";
        resultado += "Estado: " + estado + "\n";
        resultado += "#" + "\t\t" + "Cantidad" + "\t\t" + "Producto" + "\n";
        int i = 0;
        for (LineaOrdenCompra linea : lineas) {
            resultado += i + "\t\t" + linea.toString();
            i++;
        }
        resultado += "Costo: " + calcularCosto() + "\n";
        resultado += "Impuesto: " + calcularImpuesto() + "\n";
        resultado += "Total: " + calcularTotal() + "\n";
        return resultado;
    }
}
