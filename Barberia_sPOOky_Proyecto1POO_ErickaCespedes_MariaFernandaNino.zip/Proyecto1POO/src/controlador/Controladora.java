/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import excepciones.*;
import java.io.*;
import modelo.*;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.*;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.management.InvalidApplicationException;
import javax.swing.JOptionPane;

/**
 *
 * @author ericka
 */
public class Controladora implements Serializable{
    private  ArrayList<Cliente> clientes;
    private  ArrayList<Cita> citas;
    private  ArrayList<Servicio> servicios;
    private  ArrayList<Cliente> listaEspera;
    private  ArrayList<HorarioAtencion> horarios;
    
    //Singleton
    private static Controladora instance;
    
    //Constructor
    public Controladora() {
        clientes = new ArrayList();
        citas = new ArrayList();
        servicios = new ArrayList();
        listaEspera = new ArrayList();
        horarios = new ArrayList();
    }
    
    /*
    ----------------------------------------------------------------------------
    ---------------METODOS UTILES PARA EL CORRECTO FUNCIONAMIENTO---------------
    ----------------------------------------------------------------------------
    */
    
    //retorna true si el correo es valido, sino false
    private boolean correoValido(String email) {
        try{
           String patron = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
           Pattern p = java.util.regex.Pattern.compile(patron);
           Matcher m = p.matcher(email);
           return m.matches();
        }catch(Exception ex){
            return false;
        }
    }

    private boolean existeCliente(String email){
        for(Cliente c : clientes){
            if(c.getEmail().equalsIgnoreCase(email)){
                return true;
            }
        }
        return false;
    }
    
    private boolean existeCita(int numCita){
        for(Cita c : citas){
            if(c.getNumero() == numCita){
                return true;
            }
        }
        return false;
    }
    
    private boolean existeServicio(int numServicio){
        for(Servicio s : servicios){
            if(s.getNumero() == numServicio){
                return true;
            }
        }
        return false;
    }
    
    private static boolean esInteger(String cadena){
        cadena = cadena.trim();
        boolean resultado;
        try {
            if(cadena.equals("")){
                return false;
            }
        Integer.parseInt(cadena);
        resultado = true;
        } catch (NumberFormatException ex) {
            resultado = false;
        }
        return resultado;
    }
    
    private boolean tieneCitas(String email) throws java.lang.Exception{
       Cliente clienteTemp = obtenerCliente(email);
       
       for(Cita c : citas){
           if(c.getCliente() == clienteTemp){
               return true;
           }
       }
       return false;
    }
    
    private boolean elServicioEstaEnCita(int numServicio) throws Exception{
       Servicio serv = obtenerServicio(numServicio);
       
       for(Cita c : citas){
           if(c.getServicio() == serv){
               return true;
           }
       }
       return false;
    }
    
    private boolean estaEnListaDeEspera(String email) throws java.lang.Exception{
        Cliente clienteTemp = obtenerCliente(email);
       
       for(Cliente c : listaEspera){
           if(c == clienteTemp){
               return true;
           }
       }
       return false;
    }
    
    
    public void enviarCorreo(String para, String asunto, String texto) throws Exception{
        try{
            String host = "smtp.gmail.com";
            String de = "barberia.citas@gmail.com";
            String contrasena = "barberia2018";
            Properties props = System.getProperties();
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.host", host);
            props.put("mail.smtp.user", de);
            props.put("mail.smtp.password", contrasena);
            props.put("mail.smtp.port", "587");
            props.put("mail.smtp.auth", "true");

            String[] to = {para};

            Session session = Session.getDefaultInstance(props, null);
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(de));

            InternetAddress[] toAddress = new InternetAddress[to.length];

            for( int i=0; i < to.length; i++ ) {
                toAddress[i] = new InternetAddress(to[i]);
            }
            System.out.println(Message.RecipientType.TO);

            for( int i=0; i < toAddress.length; i++) {
                message.addRecipient(Message.RecipientType.TO, toAddress[i]);
            }
            message.setSubject(asunto);
            message.setText(texto);
            Transport transport = session.getTransport("smtp");
            transport.connect(host, de, contrasena);
            transport.sendMessage(message, message.getAllRecipients());
            transport.close();
        }catch(Exception ex){
            throw ex;
        } 
    }
    
    /*
    ----------------------------------------------------------------------------
    --------------------------CLIENTES------------------------------------------
    ----------------------------------------------------------------------------
    */
   
    private Cliente obtenerCliente(String email) throws Exception{
        for(Cliente c : clientes){
            if(c.getEmail().equalsIgnoreCase(email)){
                return c;
            }
        }
        throw new InvalidClientException("");
        //throw new Exception("El correo ingresado no está asociado a ningun cliente.");
    }
    
    public ArrayList<String> consultarEmail(){
        ArrayList<String> res = new ArrayList();
        for (Cliente cliente: clientes) {
            res.add(cliente.getEmail());
        }
        return res;
       
    }
    
    public void crearCliente(String nombre, String email, String telefono) throws Exception{
       if(!correoValido(email)){
           throw new InvalidEmailException("");
           //throw new Exception("Correo invalido.");
           //aqui debe volver a pedir correo.. pero eso se hace en la vista(?)
       }
       
       if(existeCliente(email)){
           throw new ExistingClientException("");
           //throw new Exception("Cliente registrado anteriormente.");
           //aqui se sale por completo y se va a la seccion de "Administracion"
       }
       
       if(!esInteger(telefono)){
           throw new InvalidPhoneNumberException("");
           //throw new Exception("Numero de telefono invalido.");
           //aqui debe volver a pedir telefono.. pero eso se hace en la vista(?)
       }
       Cliente cliente = new Cliente(nombre, email, telefono);
       clientes.add(cliente);
    }
    
    public void modificarNombre(String email, String nombre) throws java.lang.Exception{
        if(!correoValido(email)){
            throw new InvalidEmailException("");
            //throw new Exception("El correo del cliente es invalido.");
        }
        if(!existeCliente(email)){
           throw new InvalidClientException("");
        }
        try{
            Cliente c = obtenerCliente(email);
            c.setNombre(nombre);
        }catch(Exception ex){
            throw Exception(ex);
        }
    }
    
    public void modificarEmail(String email1, String email2) throws java.lang.Exception{
        if(!correoValido(email1)){
            throw new InvalidEmailException("");
            //throw new Exception("El correo del cliente es invalido.");
        }
        
        if(!existeCliente(email1)){
           throw new InvalidClientException("");
        }
        
        if(!correoValido(email2)){
            throw new InvalidEmailException("El correo nuevo es invalido.");
            //throw new Exception("El correo nuevo es invalido.");
        }
        
        if(existeCliente(email2)){
            throw new ExistingClientException("El correo nuevo esta asociado a un cliente existente.");
        }
        
        try{
            Cliente c = obtenerCliente(email1);
            c.setEmail(email2);
        }catch(Exception ex){
            throw Exception(ex);
        }
    }
    
    public void modificarTelefono(String email, String telefono) throws Exception{
        if(!correoValido(email)){
            throw new InvalidEmailException("");
            //throw new Exception("El correo del cliente es invalido.");
        }
        
        if(!existeCliente(email)){
           throw new InvalidClientException("");
        }
        
        if(!esInteger(telefono)){
            throw new InvalidPhoneNumberException("");
            //throw new Exception("Numero de telefono invalido.");
        }
        try{
            Cliente c = obtenerCliente(email);
            c.setTelefono(telefono);
        }catch(Exception ex){
            throw Exception(ex);
        }
    }
    
    public void borrarCliente(String email) throws java.lang.Exception{
        if(!correoValido(email)){
            throw new InvalidEmailException("");
            //throw new Exception("El correo del cliente es invalido.");
        }
        
        if(!existeCliente(email)){
           throw new InvalidClientException("");
       }
        
        if(tieneCitas(email)){
            throw new Exception("El cliente no puede ser eliminado ya que tiene citas pendientes.");
        }
        
        if(estaEnListaDeEspera(email)){
            throw new Exception("El cliente no puede ser eliminado ya que se encuentra en lista de espera.");
        }
        try{
            Cliente c = obtenerCliente(email);
            clientes.remove(c);
        }catch(Exception ex){
            throw Exception(ex);
        }
    }
    
    public ArrayList<String> consultarCliente(String email) throws java.lang.Exception{
        if(!correoValido(email)){
           throw new InvalidEmailException("");
           //throw new Exception("Correo invalido.");
           //aqui debe volver a pedir correo.. pero eso se hace en la vista(?)
       }
       if(!existeCliente(email)){
           throw new InvalidClientException("");
          // throw new Exception("Cliente no registrado.");
            //aqui debe volver a pedir correo.. pero eso se hace en la vista(?)
       }
        ArrayList<String> res = new ArrayList();
        Cliente temp = obtenerCliente(email);
        res.add(temp.getNombre());
        res.add(temp.getEmail());
        res.add(temp.getTelefono());
        
        return res;
       
    }
    
    /*
    ----------------------------------------------------------------------------
    -------------------------------CITAS----------------------------------------
    ----------------------------------------------------------------------------
    */
    /*
    Obtener Cita
    */
    private Cita obtenerCita(int numeroCita) throws Exception{
        for (Cita cita: citas) {
            int numero = cita.getNumero();
            if (numero == numeroCita) {
                return cita;
            }
        }
        throw new InvalidAppointment("");
        //throw new Exception("El número ingresado no está asociado a "
          //              + "ninguna cita.");
    }
    
     public String obtenerInfoDeCita(int numeroCita) throws java.lang.Exception{
         if(existeCita(numeroCita)){
             String res = "";
             
             Cita temp = obtenerCita(numeroCita);
             
             res = temp.toString();
             return res;
         }
        throw new UnexistingAppointmentException("");
     }
     
     public ArrayList<String> obtenerInfoCitaArray(int numCita) throws InvalidAppointment, java.lang.Exception{
        ArrayList<String> res = new ArrayList();
        if(!existeCita(numCita)){
            throw new InvalidAppointment("");
        }
        try{
            Cita c = obtenerCita(numCita);
            res.add(String.valueOf(c.getNumero()));
            res.add(c.getCliente().getEmail());
            String fecha = c.getDia() + "/" + c.getMes() + "/" + c.getAno(); 
            res.add(fecha);
            res.add(String.valueOf(c.getHora()));
            res.add(c.getServicio().getNombre());
            return res;
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex.toString());
        }
        throw new Exception("");
     }
    
     public ArrayList<String> consultarNumerosdeCitas(){
        ArrayList<String> res = new ArrayList();
        for (Cita c: citas) {
            res.add(String.valueOf(c.getNumero()));
        }
        return res;
       
    }
    
    /*
    Crear Cita
    */
    public int crearCita(int dia, int mes, int ano, int hora, String email, int numeroServicio) throws Exception {
        Cliente cliente = obtenerCliente(email);
        Servicio servicio = obtenerServicio(numeroServicio);
        long duracion = servicio.getDuracion();
        if ( isAbiertoFecha(dia, mes, ano) == false) {
            throw new DateOutOfBoundException("");
        }
        else if ( isAbiertoHora(dia, mes, ano, hora, duracion) == false ) {
            throw new ScheduleOutOfBoundException("");
        }
        else if ( isHoraLibre(dia, mes, ano, hora) == false ) {
            throw new BusyScheduleException("");
        }
        else {
            //Cita(int dia, int mes, int ano, int hora, Cliente cliente, Servicio servicio)
            Cita cita = new Cita(dia, mes, ano, hora, cliente, servicio);
            citas.add(cita);
            return cita.getNumero();
        }
    }
    
    /*
    Modificadores de fecha, hora, cliente y servicio
    */
    
    
    public void modificarFecha(int numeroCita, int dia, int mes, int ano) throws Exception {
        modificarDia(numeroCita, dia);
        modificarMes(numeroCita, mes);
        modificarAno(numeroCita, ano);
    }
    
    public void modificarDia(int numeroCita, int dia) throws Exception {
        Cita cita = obtenerCita(numeroCita);
        
        /////mary agrego esto//////////////////////////////////////////////////
        Servicio serv = obtenerServicio(cita.getServicio().getNumero());
        if ( isAbiertoHora(dia, cita.getMes(), cita.getAno(), cita.getHora(),serv.getDuracion()) == false) {
            throw new ScheduleOutOfBoundException("");
        }
        else if ( isHoraLibre(dia, cita.getMes(), cita.getAno(), cita.getHora()) == false ) {
            throw new BusyScheduleException("");
        }
        ///////////////////////////////////////////////////////////////////////
        cita.setDia(dia);
    }
    public void modificarMes(int numeroCita, int mes) throws Exception {
        Cita cita = obtenerCita(numeroCita);
        
        /////mary agrego esto//////////////////////////////////////////////////
        Servicio serv = obtenerServicio(cita.getServicio().getNumero());
        if ( isAbiertoHora(cita.getDia(), mes, cita.getAno(), cita.getHora(),serv.getDuracion()) == false) {
            throw new ScheduleOutOfBoundException("");
        }
        else if ( isHoraLibre(cita.getDia(), mes, cita.getAno(), cita.getHora()) == false ) {
            throw new BusyScheduleException("");
        }
        ///////////////////////////////////////////////////////////////////////
        cita.setMes(mes);
    }
    public void modificarAno(int numeroCita, int ano) throws Exception {
        Cita cita = obtenerCita(numeroCita);
        /////mary agrego esto//////////////////////////////////////////////////
        Servicio serv = obtenerServicio(cita.getServicio().getNumero());
        if ( isAbiertoHora(cita.getDia(), cita.getMes(), ano, cita.getHora(),serv.getDuracion()) == false) {
            throw new ScheduleOutOfBoundException("");
        }
        else if ( isHoraLibre(cita.getDia(), cita.getMes(), ano, cita.getHora()) == false ) {
            throw new BusyScheduleException("");
        }
        ///////////////////////////////////////////////////////////////////////
        cita.setAno(ano);
    }
    public void modificarHora(int numeroCita, int hora) throws Exception {
        Cita cita = obtenerCita(numeroCita);
        /////mary agrego esto//////////////////////////////////////////////////
        Servicio serv = obtenerServicio(cita.getServicio().getNumero());
        if ( isAbiertoHora(cita.getDia(), cita.getMes(), cita.getAno(), hora, serv.getDuracion()) == false) {
            throw new ScheduleOutOfBoundException("");
        }
        else if ( isHoraLibre(cita.getDia(), cita.getMes(), cita.getAno(), hora) == false ) {
            throw new BusyScheduleException("");
        }
        ///////////////////////////////////////////////////////////////////////
        cita.setHora(hora);
    }
    
    public void modificarCliente(int numeroCita, String email) throws Exception {
        if(!existeCita(numeroCita)){
            throw new InvalidAppointment("");
        }
        if(!correoValido(email)){
            throw new InvalidEmailException("");
        }
        if(!existeCliente(email)){
            throw new InvalidClientException("");
        }
        Cliente cliente = obtenerCliente(email);
        Cita cita = obtenerCita(numeroCita);
        cita.setCliente(cliente);
    }
    public void modificarServicio(int numeroCita, int numeroServicio) throws Exception {
        if(!existeCita(numeroCita)){
            throw new InvalidAppointment("");
        }
        if(!existeServicio(numeroServicio)){
            throw new InvalidServiceException("");
        }
        Servicio servicio = obtenerServicio(numeroServicio);
        Cita cita = obtenerCita(numeroCita);
        cita.setServicio(servicio);
    }
    /*
    Borrar Cita
    */
    public void borrarCita(int numeroCita) throws Exception {
        if(!existeCita(numeroCita)){
            throw new InvalidAppointment("");
        }
        Cita cita = obtenerCita(numeroCita);
        citas.remove(cita);
    }
    /*
    Consultar cita
    */
    public String consultarCita(int numeroCita) throws Exception {
        if(!existeCita(numeroCita)){
            throw new InvalidAppointment("");
        }
        Cita cita = obtenerCita(numeroCita);
        return cita.toString();
    }
    
    //para llenar la tabla en la GUI
    public ArrayList<String []> returnCitasporDiayMes(){
        //Se obtiene la fecha de hoy para encontrar la de mañana
        LocalDateTime hoy = LocalDateTime.now();
        LocalDateTime fechaManana = hoy.plusDays(1);
        //Se obtiene el día y el mes de mañana
        int diaManana = fechaManana.getDayOfMonth();
        int mesManana = fechaManana.getMonthValue();
        int anoManana = fechaManana.getYear();
        
        ArrayList<Cita> citasDiaSiguiente = obtenerCitasPorDiayMes(diaManana,mesManana, anoManana);
        ArrayList<String []> res = new ArrayList();
        
        for (int i = 0; i < citasDiaSiguiente.size(); i++) {
            Cita temp = citasDiaSiguiente.get(i);
            String [] info = new String [3];
            info[0] = temp.getCliente().getNombre();
            info[1] = temp.getCliente().getEmail();
            info[2] = temp.toString();
            res.add(info);
        }
        return res;
    }
    
    public void BORRARCITASPRUEBA(){
        citas.clear();
    }
    /*
    Enviar Confirmacion
    */
    
    public ArrayList<String> obtenerLasCitasDeManana(){
        LocalDateTime hoy = LocalDateTime.now();
        LocalDateTime fechaManana = hoy.plusDays(1);
        //Se obtiene el día y el mes de mañana
        int diaManana = fechaManana.getDayOfMonth();
        int mesManana = fechaManana.getMonthValue();
        int anoManana = fechaManana.getYear();
        
        ArrayList<Cita> citasDiaSiguiente = obtenerCitasPorDiayMes(diaManana,mesManana, anoManana);
        ArrayList<String> misCitas = new ArrayList();
        
        for(Cita c : citasDiaSiguiente){
            misCitas.add(c.toString());
        }
        return misCitas;
    }
    
    public void enviarConfirmacion() throws UnexistingAppointmentException, java.lang.Exception {
        //Se obtiene la fecha de hoy para encontrar la de mañana
        LocalDateTime hoy = LocalDateTime.now();
        LocalDateTime fechaManana = hoy.plusDays(1);
        //Se obtiene el día y el mes de mañana
        int diaManana = fechaManana.getDayOfMonth();
        int mesManana = fechaManana.getMonthValue();
        int anoManana = fechaManana.getYear();
        
        ArrayList<Cita> citasDiaSiguiente = obtenerCitasPorDiayMes(diaManana,mesManana, anoManana);
        
        if(citasDiaSiguiente.isEmpty()){
            throw new UnexistingAppointmentException("");
        }
        
        for (Cita cita : citasDiaSiguiente) {
            Cliente cliente = cita.getCliente();
            String email = cliente.getEmail();
            //-> Enviar email!
            String correo = "\nBarberia sPOOky le recuerda confirmar su cita "
                            + "programada para: " + diaManana + "/" + mesManana + "/" + anoManana + ".";
            
            try {
                enviarCorreo(email, "Confirmacion de Cita", correo);
            } catch (java.lang.Exception ex) {
                throw ex;
            }
            
        }
    }
    /*
    Confirmar cita
    */
    public void confirmarCita(int numeroCita) throws Exception {
        if(!existeCita(numeroCita)){
            throw new InvalidAppointment("");
        }
        Cita cita = obtenerCita(numeroCita);
        
        if(cita.getEstadoCita() == EstadoCita.CONFIRMADA){
            throw new Exception("La cita ya esta confirmada.");
        }
        cita.setEstadoCita(EstadoCita.CONFIRMADA);
    }
    /*
    Ver calendario
    Mostrar en pantalla la programación de citas por semana o por mes según el usuario indique.
    */
    //Buscar citas filtradas por mes
//    private ArrayList<Cita> obtenerCitasPorMes(int mesBuscado) {
//        ArrayList<Cita> citasPorMes = new ArrayList();
//        for (Cita cita : citas) {
//            //Se obtiene la fecha de cada cita, su día y el mes
//            LocalDateTime fecha = cita.getFecha();
//            int mes = fecha.getMonthValue();
//            //El día y mes de la cita que concuerde con las de mañana se seleccionan
//            if ( mesBuscado == mes ) {
//                citasPorMes.add(cita);
//            }
//        }
//        return citasPorMes;
//    }
    //Buscar citas filtradas por dia y mes
    private ArrayList<Cita> obtenerCitasPorDiayMes(int diaBuscado, int mesBuscado, int anoBuscado) {
        ArrayList<Cita> citasPorDiayMes = new ArrayList();
        //Se recorren las citas
        for (Cita cita : citas) {
            //Se obtiene la fecha de cada cita, su día y el mes v
            int dia = cita.getDia();
            int mes = cita.getMes();
            int ano = cita.getAno();
            //El día y mes de la cita que concuerde con las de mañana se seleccionan
            if ( diaBuscado == dia && mesBuscado == mes && anoBuscado == ano ) {
                citasPorDiayMes.add(cita);
            }
        }
        
        
        
        return citasPorDiayMes;
    }
    
    public ArrayList<String> verCalendarioPorMes() throws Exception {
        
//        if(citas.isEmpty()){
//            System.out.println("citas empty");
//        }else{
//            System.out.println("citas no esta empty");
//        }
        
        ArrayList<String> resultado = new ArrayList();
        ArrayList<LocalDate> fechas = new ArrayList();
        LocalDate dia = LocalDate.now();
        fechas.add( dia );
        for (int i = 1; i<31; i++) {
            dia = dia.plusDays(1);
            fechas.add( dia );
        }
        ArrayList<Cita> citasPorMes = new ArrayList();
        for (LocalDate fecha : fechas) {
            int diaBuscado = fecha.getDayOfMonth();
            int mesBuscado = fecha.getMonthValue();
            int anoBuscado = fecha.getYear();
            citasPorMes.addAll(obtenerCitasPorDiayMes(diaBuscado, mesBuscado, anoBuscado));
        }
        for (Cita cita : citasPorMes) {
            resultado.add( cita.toString() );
        }
        
        return resultado;
    }
    
    public ArrayList<String> verCalendarioPorSemana() {
        ArrayList<String> resultado = new ArrayList();
        ArrayList<LocalDate> fechas = new ArrayList();
        LocalDate dia = LocalDate.now();
        fechas.add( dia );
        for (int i = 1; i<7; i++) {
            dia = dia.plusDays(1);
            fechas.add( dia );
        }
        ArrayList<Cita> citasPorSemana = new ArrayList();
        for (LocalDate fecha : fechas) {
            int diaBuscado = fecha.getDayOfMonth();
            int mesBuscado = fecha.getMonthValue();
            int anoBuscado = fecha.getYear();
            citasPorSemana.addAll(obtenerCitasPorDiayMes(diaBuscado, mesBuscado, anoBuscado) );
        }
        for (Cita cita : citasPorSemana) {
            resultado.add( cita.toString() );
        }
        return resultado;
    }

    /*
    ----------------------------------------------------------------------------
    --------------------------SERVICIOS-----------------------------------------
    ----------------------------------------------------------------------------
    */
    private Servicio obtenerServicio(int numeroServicio) throws Exception{
        for (Servicio servicio : servicios) {
            int numero = servicio.getNumero();
            if (numero == numeroServicio) {
                return servicio;
            }
        }
        throw new InvalidServiceException("");
       // throw new Exception("El número ingresado no está asociado a "
       //                 + "ningun servicio.");
    }
    
    public ArrayList<String> consultarNumerosDeServicios(){
        ArrayList<String> res = new ArrayList();
        for (Servicio s: servicios) {
            res.add(String.valueOf(s.getNumero()));
        }
        return res;
       
    }
    
    public int crearServicio(String nombre, float precio, String unidad, long duracion) {
        Servicio servicio = new Servicio(nombre, precio, unidad, duracion);
        servicios.add(servicio);
        return servicio.getNumero();
    }
    public void modificarServicio(int numeroServicio, String nombre) throws Exception {
        if(!existeServicio(numeroServicio)){
            throw new InvalidServiceException("");
        }   
        Servicio servicio = obtenerServicio(numeroServicio);
        servicio.setNombre(nombre);
    }
    public void modificarPrecio(int numeroServicio, float precio) throws Exception {
        if(!existeServicio(numeroServicio)){
            throw new InvalidServiceException("");
        }  
        Servicio servicio = obtenerServicio(numeroServicio);
        servicio.setPrecio(precio);
    }
    public void modificarUnidad(int numeroServicio, String unidad) throws Exception {
        if(!existeServicio(numeroServicio)){
            throw new InvalidServiceException("");
        }  
        Servicio servicio = obtenerServicio(numeroServicio);
        servicio.setUnidad(unidad);
    }
    public void modificarDuracion(int numeroServicio, long duracion) throws Exception {
        if(!existeServicio(numeroServicio)){
            throw new InvalidServiceException("");
        }  
        Servicio servicio = obtenerServicio(numeroServicio);
        servicio.setDuracion(duracion);
    }
    public void borrarServicio(int numeroServicio) throws Exception {
        if(!existeServicio(numeroServicio)){
            throw new InvalidServiceException("");
        }
        if(elServicioEstaEnCita(numeroServicio)){
            throw new Exception("El servicio no se puede eliminar ya que este se brinda en citas pendientes.");
        }
        Servicio servicio = obtenerServicio(numeroServicio);
        servicios.remove(servicio);
    }
    
    public ArrayList<String> consultarServicio(int numeroServicio) throws Exception {
        ArrayList<String> res = new ArrayList();
        if(!existeServicio(numeroServicio)){
            throw new InvalidServiceException("");
        }
        Servicio servicio = obtenerServicio(numeroServicio);
        res.add(String.valueOf(servicio.getNumero()));
        res.add(servicio.getNombre());
        res.add(String.valueOf(servicio.getPrecio()));
        res.add(servicio.getUnidad());
        res.add(String.valueOf(servicio.getDuracion()));
        return res;
    }
    
    public String consultaStringServicios(){
        String res = "";
        if(!servicios.isEmpty()){
            for(Servicio s : servicios){
                res = res + s.toString() + "\n";
            }
        }
        return res;
    }
    
    public void BORRARSERVICIOSPRUEBA(){
        servicios.clear();
    }
    /*
    ----------------------------------------------------------------------------
    -----------------------LISTA DE ESPERA--------------------------------------
    ----------------------------------------------------------------------------
    */
    public ArrayList<String> mostrarListaEspera() {
        ArrayList<String> resultado = new ArrayList();
        for (Cliente cliente : listaEspera) {
            resultado.add( cliente.toString() );
        }
        return resultado;
    }
    
    public void BORRARLISTAESPERAPRUEBA(){
        listaEspera.clear();
    }
    
    public ArrayList<String> mostrarListaEsperaEmails() {
        ArrayList<String> resultado = new ArrayList();
        for (Cliente cliente : listaEspera) {
            resultado.add( cliente.getEmail());
        }
        return resultado;
    }
    
    public void agregarClienteListaEspera(String email) throws Exception {
        if(!correoValido(email)){
            throw new InvalidEmailException("");
        }
        if(!existeCliente(email)){
            throw new InvalidClientException("");
        }
        if(estaEnListaDeEspera(email)){
            throw new Exception("El cliente ya en la lista de espera.");
        }
        Cliente cliente = obtenerCliente(email);
        listaEspera.add(cliente);
    }
    public void borrarClienteListaEspera(String email) throws Exception {
        if(!correoValido(email)){
            throw new InvalidEmailException("");
        }
        if(!existeCliente(email)){
            throw new InvalidClientException("");
        }
        
        Cliente cliente = obtenerCliente(email);
        listaEspera.remove(cliente);
    }
    /*
    ----------------------------------------------------------------------------
    ------------------------HORARIO DE ATENCION---------------------------------
    ----------------------------------------------------------------------------
    */
    /*
Horario de Atencion
+ establecerHorarioAtencion(dia: DiaSemana, horaInicio : LocalDateTime, horaFinal : LocalDateTime)
+ consultarHorarioAtencion(diaSemana: DiaSemana) : ArrayList<String>
    */
    private HorarioAtencion obtenerHorarioAtencion(DiaSemana diaSemana) throws Exception {
        for (HorarioAtencion horario : horarios) {
            DiaSemana dia = horario.getDia();
            if (dia == diaSemana) {
                return horario;
            }
        }
        throw new Exception("El horario consultado no existe.");
    }
    
    private boolean existeHorarioAtencion(DiaSemana diaSemana){
        for (HorarioAtencion horario : horarios) {
            DiaSemana dia = horario.getDia();
            if (dia == diaSemana) {
                return true;
            }
        }
        return false;
    }
    
    public void establecerHorarioAtencion(DiaSemana dia, int horaInicio, int horaFinal) {
        HorarioAtencion horario = new HorarioAtencion(dia, horaInicio, horaFinal);
        if(existeHorarioAtencion(dia)){
            try {
                HorarioAtencion temp = obtenerHorarioAtencion(dia);
                horarios.remove(temp);
            } catch (java.lang.Exception ex) {
                
            }
        }
        horarios.add(horario);
    }
    public String consultarHorarioAtencion(DiaSemana diaSemana) throws Exception {
        HorarioAtencion horario = obtenerHorarioAtencion(diaSemana);
        return horario.toString();
    }

    private Exception Exception(Exception ex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public void BORRARHORARIOPRUEBA(){
        horarios.clear();
    }
    
    /*
    ----------------------------------------------------------------------------
    ------------------------EXTENSIONES---------------------------------
    ----------------------------------------------------------------------------
    */
    
    private boolean isAbiertoFecha(int dia, int mes, int ano) throws Exception {
        LocalDate fecha = LocalDate.of(ano, mes, dia);
        DayOfWeek day = fecha.getDayOfWeek();
        DiaSemana diaSemana = toDiaSemana(day);
        try {
            HorarioAtencion horarioAtencion = obtenerHorarioAtencion(diaSemana);
            return true;
        }
        catch (Exception ex) {
            return false;
        }
    }
    private boolean isAbiertoHora(int dia, int mes, int ano, int hora, long duracion) throws Exception {
        LocalDateTime fecha = LocalDateTime.of(ano, mes, dia, hora, 0);
        DayOfWeek day = fecha.getDayOfWeek();
        DiaSemana diaSemana = toDiaSemana(day);
        HorarioAtencion horarioAtencion = obtenerHorarioAtencion(diaSemana);
        int horaInicio = horarioAtencion.getHoraInicio();
        int horaFinal = horarioAtencion.getHoraFinal();
        if (hora >= horaInicio && hora < horaFinal) {
            fecha.plusHours(duracion);
            int horaDuracion = fecha.getHour();
            return horaDuracion <= horaFinal;
        }
        else {
            return false;
        }
    }
    private boolean isHoraLibre(int dia, int mes, int ano, int hora) {
        for (Cita cita: citas) {
            int diaCita = cita.getDia();
            int mesCita = cita.getMes();
            int anoCita = cita.getAno();
            int horaCita = cita.getHora();
            int horaFinal = cita.calcularHoraFinal();
            if (diaCita == dia && mesCita == mes && anoCita == ano && hora >= horaCita && hora < horaFinal) {
                return false;
            }
        }
        return true;
    }
    
    private DiaSemana toDiaSemana(DayOfWeek day) throws Exception {
        if (day == DayOfWeek.MONDAY) {
            return DiaSemana.LUNES;
        }
        if (day == DayOfWeek.TUESDAY) {
            return DiaSemana.MARTES;
        }
        if (day == DayOfWeek.WEDNESDAY) {
            return DiaSemana.MIERCOLES;
        }
        if (day == DayOfWeek.THURSDAY) {
            return DiaSemana.JUEVES;
        }
        if (day == DayOfWeek.FRIDAY) {
            return DiaSemana.VIERNES;
        }
        if (day == DayOfWeek.SATURDAY) {
            return DiaSemana.SABADO;
        }
        if (day == DayOfWeek.SUNDAY) {
            return DiaSemana.DOMINGO;
        }
        else {
            throw new IllegalArgumentException();
        }
    }
    
    /*
    ----------------------------------------------------------------------------
    ------------------------CARGAR Y GUARDAR DATOS------------------------------
    ----------------------------------------------------------------------------
    */
    
    
    public static Controladora CargarDatos(){
        try{
            
            FileInputStream fis = new FileInputStream("BarberiaPOO.ser");
            ObjectInputStream ois = new ObjectInputStream(fis);
            Controladora obj_wr = (Controladora) ois.readObject();
            ois.close();
            
            return obj_wr;

        }catch(Exception ex){
            return null;
           // throw new Exception("\n" + ex.toString());
        }
        
    }
    
    
    public static void GuardarDatos(Controladora data) throws Exception{
        try{
            FileOutputStream  fos = new FileOutputStream("BarberiaPOO.ser");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(data);
            oos.flush();
            oos.close();
            
        }catch(Exception ex){
            throw new Exception("\n" + ex.toString());
        }
        
        
    }
    
    public void guardarDatosNoEstatico(Controladora data) throws Exception{
        GuardarDatos(data);
    }
    
    private void setUltimoNumeroServicio(){
        if(!servicios.isEmpty()){
            int numServ = servicios.get(servicios.size()-1).getNumero();
            Servicio.setConsecutivo(numServ+1);
        }
    }
    
    private void setUltimoNumeroCita(){
        if(!citas.isEmpty()){
            int numCita = citas.get(citas.size()-1).getNumero();
            Cita.setConsecutivo(numCita+1);
        }
    }
    
    public static Controladora CargarDatosAux(){
       // WallRose temp = wr.CargarDatos();
        Controladora obj;
        try{
            obj = CargarDatos();
        }catch(Exception ex){
            System.out.println("\ncaca catch metodo " + ex.toString());
            return null;
        }
        if(obj != null){
            return CargarDatos();
        }
        return null;
    }
    
    
    public static Controladora getInstance(){
     if(CargarDatosAux() == null){
        instance = new Controladora();
    } else {
        instance = CargarDatos();
        instance.setUltimoNumeroCita();
        instance.setUltimoNumeroServicio();
        
    }
        return instance;
    }
    
    
}


