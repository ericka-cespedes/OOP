/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package excepciones;

/**
 *
 * @author マリアフェルナンダ
 * Excepcion que se lanza cuando el cliente NO esta registrado en el sistema
 */
public class InvalidClientException extends Exception {
    public InvalidClientException(String message) {
        super(message + " - El correo ingresado no está asociado a ningun cliente.");
    }
}
