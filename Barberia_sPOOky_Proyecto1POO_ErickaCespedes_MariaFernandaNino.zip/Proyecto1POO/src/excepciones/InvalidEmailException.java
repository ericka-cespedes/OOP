/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package excepciones;

/**
 *
 * @author マリアフェルナンダ
 * Excepcion que se lanza cuando la sintaxis del correo es invalida
 */
public class InvalidEmailException extends Exception{
     public InvalidEmailException(String message) {
        super(" - El correo no es valido.");
    }
    
}
