/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package excepciones;

/**
 *
 * @author マリアフェルナンダ
 */
public class BusyScheduleException extends Exception{
    public BusyScheduleException(String message) {
        super(message + " - El horario no se encuentra disponible. "
                + "\n(osea que esta ocupado :v despues quitamos esto, es para no enredarnos con tantas exceptions :'v)");
    }
}
    