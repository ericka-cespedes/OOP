/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package excepciones;

/**
 *
 * @author マリアフェルナンダ
 */
public class ScheduleOutOfBoundException extends Exception {
    public ScheduleOutOfBoundException(String message) {
        super(message + " - La hora esta fuera del horario de atencion.");
    }
}
