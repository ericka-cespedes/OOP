/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package excepciones;

/**
 *
 * @author マリアフェルナンダ
 */
public class UnexistingScheduleException extends Exception{
    public UnexistingScheduleException(String message) {
        super(message + " - El horario de atencion no existe.");
    }
}
