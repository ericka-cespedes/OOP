/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;

import controlador.*;
import java.util.ArrayList;

/**
 *
 * @author マリアフェルナンダ
 */
public class Test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
//        Controladora ct = Controladora.getInstance();
//        try{
//            ct.crearCliente("Mary", "maf.nino7@gmail.com", "89952503");
//        }catch(Exception ex){
//            System.out.println(ex.toString());
//        }
//        
//        try{
//            ArrayList<String> temp = ct.consultarCliente("maf.nino7@gmail.com");
//            for (int i = 0; i < temp.size(); i++) {
//                System.out.println(temp.get(i));
//            }
//        }catch(Exception ex){
//            System.out.println(ex.toString());
//        }
//        
//        try{
//            ct.GuardarDatos(ct);
//        }catch(Exception ex){
//            System.out.println(ex.toString());
//        }
        
    }
    
}
