/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.io.Serializable;

/**
 *
 * @author ericka
 */

/*
Documentación
Clase Dia Semana
Creada por Ericka Céspedes
Función: Sirve para crear una enumeración de los estados de cita.
Más que todo por comodidad. Se puede hacer una variable booleana en vez de la
enumeración.
Además posee un método To String por cuestiones estéticas.
*/

public enum EstadoCita implements Serializable{
    PROGRAMADA, CONFIRMADA;
    
    @Override
    public String toString() {
        switch(this) {
        case PROGRAMADA: return "Programada";
        case CONFIRMADA: return "Confirmada";
        default: throw new IllegalArgumentException();
        }
    }
}
