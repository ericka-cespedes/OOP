/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.io.Serializable;
import java.time.DayOfWeek;

/**
 *
 * @author ericka
 */

/*
Documentación
Clase Dia Semana
Creada por Ericka Céspedes
Función: Sirve para crear una enumeración de los días de la semana.
Más que todo por comodidad y para comparar con LocalDateTime->DayOfWeek.
Además posee un método To String por cuestiones estéticas.
*/

public enum DiaSemana implements Serializable{
    LUNES, MARTES, MIERCOLES, JUEVES, VIERNES, SABADO, DOMINGO;

    public DayOfWeek getDia() {
        switch(this) {
            case LUNES: return DayOfWeek.MONDAY;
            case MARTES: return DayOfWeek.TUESDAY;
            case MIERCOLES: return DayOfWeek.WEDNESDAY;
            case JUEVES: return DayOfWeek.THURSDAY;
            case VIERNES: return DayOfWeek.FRIDAY;
            case SABADO: return DayOfWeek.SATURDAY;
            case DOMINGO: return DayOfWeek.SUNDAY;
            default: throw new IllegalArgumentException();
        }
    }
    
    @Override
    public String toString() {
        switch(this) {
            case LUNES: return "Lunes";
            case MARTES: return "Martes";
            case MIERCOLES: return "Miércoles";
            case JUEVES: return "Jueves";
            case VIERNES: return "Viernes";
            case SABADO: return "Sábado";
            case DOMINGO: return "Domingo";
            default: throw new IllegalArgumentException();
        }
    }
}
