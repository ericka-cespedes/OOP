/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.io.Serializable;
import java.time.DayOfWeek;
import java.time.LocalDateTime;

/**
 *
 * @author ericka
 */

/*
Documentación
Clase HorarioAtencion
Creada por Ericka Céspedes
Función: Sirve para crear un horario de atención para cada día de la semana.
Cada horario de atención tiene un día asignado, hora de inicio y hora final.
*/

public class HorarioAtencion implements Serializable{
    //Atributos
    private int horaInicio;
    private int horaFinal;
    private DiaSemana dia;
    
    //Constructor
    public HorarioAtencion(DiaSemana dia, int horaInicio, int horaFinal) {
        this.dia = dia;
        this.horaInicio = horaInicio;
        this.horaFinal = horaFinal;
    }
    //Setters y Getters
    public void setDia(DiaSemana dia) {
        this.dia = dia;
    }
    public DiaSemana getDia() {
        return dia;
    }
    public void setHoraInicio(int horaInicio) {
        this.horaInicio = horaInicio;
    }
    public int getHoraInicio() {
        return horaInicio;
    }
    public void setHoraFinal(int horaFinal) {
        this.horaFinal = horaFinal;
    }
    public int getHoraFinal() {
        return horaFinal;
    }
    //Métodos
    /*
    To String
    Para cada servicio se muestra día, hora de inicio y hora final del horario
    de atención.
    */
    @Override
    public String toString() {
        String resultado;
        resultado = "Día: " + dia.toString() + "\n";
        resultado += "Hora de inicio: " + horaInicio + ":00\n";
        resultado += "Hora final: " + horaFinal + ":00\n";
        return resultado;
    }
}
