/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author マリアフェルナンダ
 * 
 * Documentacion:
 * Clase Clinte
 * Creada por Maria Fernanda Nino
 * Funcion: Se crean clientes, estos son identificados por el email
 * para no agregar repetidos.
 * Cada cliente tiene una coleccion de citas que se puede consultar ya sea
 * todas, o unicamente las confirmadas o programadas.
 */
public class Cliente implements Serializable{
    private String nombre;
    private String email;
    private String telefono;
    private ArrayList<Cita> citas;
    
    private ArrayList<Cita> temp = new ArrayList();

    public Cliente(String nombre, String email, String telefono) {
        this.nombre = nombre;
        this.email = email;
        this.telefono = telefono;
        this.citas = new ArrayList();
    }
    
    public void crearCita(Cita cita){
        citas.add(cita);
    }
    
    public ArrayList<Cita> obtenerCitasTodas(){
        if(!citas.isEmpty()){
            return citas;
        }
        return null;
    }
    
    public ArrayList<Cita> obtenerCitasConfirmadas(){
        temp.clear();
        
        for(Cita c : citas){
            if(c.getEstadoCita() == EstadoCita.CONFIRMADA){
                temp.add(c);
            }
        }
        
        if(!temp.isEmpty()){
            return temp;
        }else {
            return null;
        }
        
    }
    
    public ArrayList<Cita> obtenerCitasProgramadas(){
        temp.clear();
        
        for(Cita c : citas){
            if(c.getEstadoCita() == EstadoCita.PROGRAMADA){
                temp.add(c);
            }
        }
        
        if(!temp.isEmpty()){
            return temp;
        }else {
            return null;
        }
        
    }
    
    @Override
    public String toString(){
        
        String res = "\nNombre: " + this.nombre +
                "\ne-mail: " + this.email + 
                "\nTelefono: " + this.telefono;
        
        return res;
    }
    
    
    //Propiedades

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    
    
    
    
}
