/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.io.Serializable;

/**
 *
 * @author ericka
 */

/*
Documentación
Clase Servicio
Creada por Ericka Céspedes
Función: Sirve para crear un tipo de servicio
Cada servicio tiene un número, nombre, precio y la unidad que se utiliza para
el precio.
*/

public class Servicio implements Serializable{
    //Atributos
    public static int consecutivo = 1;
    private int numero;
    private String nombre;
    private float precio;
    private String unidad;
    private long duracion;
    
    //Constructor
    public Servicio(String nombre, float precio, String unidad, long duracion) {
        this.nombre = nombre;
        this.precio = precio;
        this.unidad = unidad;
        this.duracion = duracion;
        this.numero = consecutivo;
        consecutivo++;
    }
    
    //Setters y Getters
    public static void setConsecutivo(int consecutivo) {
        Servicio.consecutivo = consecutivo;
    }
    public int getConsecutivo() {
        return consecutivo;
    }
    public void setNumero(int numero) {
        this.numero = numero;
    }
    public int getNumero() {
        return numero;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getNombre() {
        return nombre;
    }
    public void setPrecio(float precio) {
        this.precio = precio;
    }
    public float getPrecio() {
        return precio;
    }
    public void setUnidad(String unidad) {
        this.unidad = unidad;
    }
    public String getUnidad() {
        return unidad;
    }
    public void setDuracion(long duracion) {
        this.duracion = duracion;
    }
    public long getDuracion() {
        return duracion;
    }
    
    //Métodos
    /*
    To String
    Para cada servicio se muestra número, nombre, precio y unidad.
    */
    @Override
    public String toString() {
        String resultado;
        resultado = "Código del Servicio: " + numero + "\n";
        resultado += "Nombre: " + nombre + "\n";
        resultado += "Precio: " + precio + "\t\t\t\n";
        resultado += "Unidad: " + unidad + "\n";
        resultado += "Duración: " + duracion + " hora\n";
        return resultado;
    }
}
