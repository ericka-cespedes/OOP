/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 *
 * @author ericka
 */

/*
Documentación
Clase Cita
Creada por Ericka Céspedes
Función: Sirve para crear una cita.
Cada cita tiene un número, su fecha y hora, el estado (programada o confirmada),
el cliente al que pertenece la cita y el servicio que se va a realizar.
*/

public class Cita implements Serializable{
    //Atributos
    public static int consecutivo = 1;
    public static float IV = 0.13f;
    private int numero;
    private int dia;
    private int mes;
    private int ano;
    private int hora;
    private EstadoCita estado;
    private Cliente cliente;
    private Servicio servicio;
    
    //Constructor
    public Cita(int dia, int mes, int ano, int hora, Cliente cliente, Servicio servicio) {
        this.dia = dia;
        this.mes = mes;
        this.ano = ano;
        this.hora = hora;
        this.cliente = cliente;
        this.servicio = servicio;
        this.numero = consecutivo;
        consecutivo++;
        estado = EstadoCita.PROGRAMADA;
    }
    
    //Setters y Getters
    public static void setConsecutivo(int consecutivo) {
        Cita.consecutivo = consecutivo;
    }
    public int getConsecutivo() {
        return consecutivo;
    }
    public void setNumero(int numero) {
        this.numero = numero;
    }
    public int getNumero() {
        return numero;
    }
    public void setDia(int dia) {
        this.dia = dia;
    }
    public int getDia() {
        return dia;
    }
    public void setMes(int mes) {
        this.mes = mes;
    }
    public int getMes() {
        return mes;
    }
    public void setAno(int ano) {
        this.ano = ano;
    }
    public int getAno() {
        return ano;
    }
    public void setHora(int hora) {
        this.hora = hora;
    }
    public int getHora() {
        return hora;
    }
    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
    public Cliente getCliente() {
        return cliente;
    }
    public void setServicio(Servicio servicio) {
        this.servicio = servicio;
    }
    public Servicio getServicio() {
        return servicio;
    }
    public void setEstadoCita(EstadoCita estado) {
        this.estado = estado;
    }
    public EstadoCita getEstadoCita() {
        return estado;
    }
    
    //Métodos
    public long calcularDuracion() {
        return servicio.getDuracion();
    }
    
    public int calcularHoraFinal() {
        int horaFinal;
        LocalDateTime fecha = LocalDateTime.of(ano, mes, dia, hora, 0);
        fecha.plusHours(servicio.getDuracion());
        horaFinal = fecha.getHour();
        return horaFinal;
    }
    
    /*
    Calcular Costo
    Calcula el costo del servicio de la cita
    */
    //Recomendaciones, cosas a mejorar que no se piden
    //Aqui se puede hacer hasta un ArrayList de servicios para agregar mas de un servicio si fuera necesario
    public float calcularCosto() {
        float resultado = servicio.getPrecio();
        return resultado;
    }
    /*
    Calcular Impuesto
    Calcula el impuesto del costo de la cita
    */
    //Este metodo se puede eliminar y agregar de una vez en el total como:
    // + (calcularCosto() * IV);
    public float calcularImpuesto() {
        return calcularCosto() * IV;
    }
    /*
    Calcular Total
    Calcula el total a pagar de la cita
    */
    public float calcularTotal() {
        return calcularCosto() + calcularImpuesto();
    }
    @Override
    /*
    To String
    Para cada cita se muestra número, fecha, hora, cliente, servicio,
    estado de la cita (programada o confirmada), costo, monto por impuesto y total.
    */
    public String toString() {
        String resultado;
        resultado = "Número de cita: " + numero + "\n";
        resultado += "Fecha: " + dia + "/" + mes + "/" + ano + "\t\t\t\n";
        resultado += "Hora: " + hora + "\n";
        resultado += "Cliente: " + cliente.getNombre() + "\n";
        resultado += "Servicio: " + servicio + "\n";
        resultado += "Estado de Cita: " + estado + "\n"; //No es necesario
        resultado += "Costo: " + calcularCosto() + "\n";
        resultado += "Impuesto: " + calcularImpuesto() + "\n";
        resultado += "Total: " + calcularTotal() + "\n";
        return resultado;
    }
}
