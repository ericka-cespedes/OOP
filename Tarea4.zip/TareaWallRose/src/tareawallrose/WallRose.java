/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tareawallrose;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author ericka
 */
public class WallRose implements Serializable {

    /**
     * @param args the command line arguments
     */
    
    private final ArrayList<Cliente> clientes;
    private final ArrayList<OrdenCompra> ordenes;
    private final ArrayList<Producto> productos;
    
    public WallRose() {
        clientes = new ArrayList();
        ordenes = new ArrayList();
        productos = new ArrayList();
    }
    
    private Cliente obtenerCliente(int numero) throws Exception{
        for (Cliente cliente: clientes) {
            int codigo = cliente.getNumero();
            if (codigo == numero) {
                return cliente;
            }
        }
        throw new Exception("El número ingresado no está asociado a "
                        + "ningún cliente.");
    }
    private Producto obtenerProducto(int codigo) throws Exception {
        for (Producto producto: productos) {
            int numero = producto.getCodigo();
            if (numero == codigo) {
                return producto;
            }
        }
        throw new Exception("El código ingresado no está asociado a "
                        + "ningún producto.");
    }
    private OrdenCompra obtenerOrdenCompra(int numero) throws Exception {
        for (OrdenCompra orden: ordenes) {
            int codigo = orden.getNumero();
            if (codigo == numero) {
                return orden;
            }
        }
        throw new Exception("El número ingresado no está asociado a "
                        + "ninguna orden de compra.");
    }
    /*
    ----------------------------------------------------------------------------
    --------------------------CLIENTES------------------------------------------
    ----------------------------------------------------------------------------
    */
    /*
    Ver lista de clientes
    Se muestra una lista con todos los clientes registrados en el sistema.
    Se muestra número, nombre y email.
    */
    public ArrayList<String> verListaClientes() {
        ArrayList<String> resultado = new ArrayList();
        for (Cliente cliente: clientes) {
            resultado.add( cliente.toString() );
        }
        return resultado;
    }
    /*
    Agregar cliente
    Se pide al usuario que escriba un nombre y un email.
    Se crea un cliente nuevo y se guarda en la lista de clientes.
    */
    public int agregarCliente(String nombre, String email) {
        Cliente cliente = new Cliente(nombre, email);
        clientes.add(cliente);
        return cliente.getNumero();
    }
    /*
    Ver todas las órdenes
    Primero se muestra la lista de los clientes registrados en el sistema para
    que el usuario vea el número de cada uno.
    Luego se pide al usuario que escriba un código de cliente.
    Si el código es válido,
        se muestra en pantalla la lista de todas las órdenes asociadas al
        cliente elegido. Para cada orden se muestra número, fecha, estado,
        líneas que la conforman, costo, monto por impuesto y total.
    Si el código no es válido,
        se muestra un mensaje de error y se regresa al menú de clientes
    */
    public ArrayList<String> obtenerOrdenesClienteTodas (int numeroCliente) throws Exception {
        Cliente cliente = obtenerCliente(numeroCliente);
        //Lista de todas las órdenes asociadas al cliente elegido
        ArrayList<OrdenCompra> ordenesTodas = cliente.obtenerOrdenesTodas();
        //Resultado
        ArrayList<String> resultado = new ArrayList();
        for (OrdenCompra orden : ordenesTodas) {
            resultado.add( orden.toString() );
        }
        return resultado;
    }
    /*
    Ver órdenes iniciadas
    Similar a la opción anterior, pero la lista sólo contiene órdenes que se
    encuentran en estado iniciado.
    */
    public ArrayList<String> obtenerOrdenesClienteIniciadas(int numeroCliente) throws Exception {
        Cliente cliente = obtenerCliente(numeroCliente);
        //Lista de todas las órdenes en estado iniciado
        ArrayList<OrdenCompra> ordenesTodas = cliente.obtenerOrdenesIniciadas();
        //Resultado
        ArrayList<String> resultado = new ArrayList();
        for (OrdenCompra orden : ordenesTodas) {
            resultado.add( orden.toString() );
        }
        return resultado;
    }
    /*
    Ver órdenes pendientes de pago
    Similar a la opción anterior, pero la lista sólo contiene órdenes que se
    encuentran en estado pendiente de pago. 
    */
    public ArrayList<String> obtenerOrdenesClientePendientes(int numeroCliente) throws Exception {
        Cliente cliente = obtenerCliente(numeroCliente);
        //Lista de todas las órdenes en estado pendiente
        ArrayList<OrdenCompra> ordenesTodas = cliente.obtenerOrdenesPendientes();
        //Resultado
        ArrayList<String> resultado = new ArrayList();
        for (OrdenCompra orden : ordenesTodas) {
            resultado.add( orden.toString() );
        }
        return resultado;
    }
    /*
    Ver órdenes completas
    Similar a la opción anterior, pero la lista sólo contiene órdenes que se
    encuentran en estado completado.
    */
    public ArrayList<String> obtenerOrdenesClienteCompletadas(int numeroCliente) throws Exception {
        Cliente cliente = obtenerCliente(numeroCliente);
        //Lista de todas las órdenes en estado iniciado
        ArrayList<OrdenCompra> ordenesTodas = cliente.obtenerOrdenesCompletadas();
        //Resultado
        ArrayList<String> resultado = new ArrayList();
        for (OrdenCompra orden : ordenesTodas) {
            resultado.add( orden.toString() );
        }
        return resultado;
    }
    /*
    Calcular total pendiente de un cliente
    Se suma el costo de todas las órdenes 
    */
    public float calcularTotalPendienteCliente(int numeroCliente) throws Exception {
        Cliente cliente = obtenerCliente(numeroCliente);
        ArrayList<OrdenCompra> ordenesPendientes = new ArrayList();
        ordenesPendientes.addAll( cliente.obtenerOrdenesPendientes() );
        //Se calcula el total pendiente calculando el total de cada orden pendiente
        float resultado = 0;
        for (OrdenCompra orden : ordenesPendientes) {
            resultado += orden.calcularTotal();
        }
        return resultado;
    }
    
    /*
    ----------------------------------------------------------------------------
    ---------------------ORDENES DE COMPRA--------------------------------------
    ----------------------------------------------------------------------------
    */
    /*
    Ver lista de órdenes de compra
    Se muestra una lista con todas las órdenes que existen en el sistema.
    Por cada orden se muestra número, fecha y estado.
    */
    public ArrayList<String> verListaOrdenes() {
        ArrayList<String> resultado = new ArrayList();
        String res;
        for (OrdenCompra orden : ordenes) {
            resultado.add( orden.toString() );
        }
        return resultado;
    }
    /*
    Ver Orden
    Se muestra la orden completa con todos sus detalles y líneas.
    */
    public String verOrden(int numeroOrden) throws Exception {
        OrdenCompra ordenCompra = obtenerOrdenCompra(numeroOrden);
        return ordenCompra.toString();
    }
    /*
    Crear nueva órden de compra
    Primero se muestra una lista con todos los clientes registrados para que el
    usuario vea el número de cada uno.
    Luego se pide que escriba el número de cliente al que se le quiere crear la
    orden de compra.
    Si el número de cliente es válido,
        se crea una nueva orden de compra vacía, se agrega a la lista de órdenes
    de compra y se muestra un mensaje que indica que se creó correctamente y el
    número de la orden creada.
    Si el número de cliente no es válido,
        se muestra un mensaje de error y se regresa al menú de órdenes de compra.
    */
    public int crearOrden(int numeroCliente) throws Exception {
        Cliente cliente = obtenerCliente(numeroCliente);
        //Nueva orden de compra vacía
        OrdenCompra orden = new OrdenCompra(cliente);
        //Se agrega a la lista de órdenes de compra
        cliente.agregarOrden(orden);
        ordenes.add(orden);
        return orden.getNumero();
    }
    /*
    Agregar línea a una orden de compra
    Se muestra en pantalla una lista con todas las órdenes registradas en el
    sistema para que el usuario vea el número de cada una.
    Luego se pide al usuario que escriba un número de orden.
    Si el número de orden es válido,
        se muestra una lista con todos los productos registrados en el sistema
        para que el usuario vea el código de cada uno.
        Se pide al usuario que escriba un código de producto y
        luego la cantidad de ese producto para agregar la línea en dicha orden
        de compra. Se debe restar de las existencias del producto la cantidad
        agregada en la línea.
    Sí el número de orden o el código del producto no es válido,
        se muestra un mensaje de error y se regresa al menú de órdenes de compra.
    */
    public void agregarLineaOrden(int numeroOrden, int codigoProducto, float cantidad) throws Exception {
        OrdenCompra ordenCompra = obtenerOrdenCompra(numeroOrden);
        Producto producto = obtenerProducto(codigoProducto);
        ordenCompra.agregarLinea(cantidad, producto);
        //Se debe restar de las existencias del producto la cantidad
        //agregada en la línea.
        producto.retirarExistencias(cantidad);
    }
    /*
    Borrar línea de una orden de compra
    Se muestra en pantalla una lista con todas las órdenes registradas en el
    sistema para que el usuario vea el número de cada una.
    Luego se pide al usuario que escriba el número de orden.
    Si el número de orden es válido,
        se muestra la orden completa con todos sus detalles y líneas.
        Luego se pide al usuario que escriba el número de línea que desea borrar
        y se elimina de la orden de compra.
        Se debe sumar a las existencias del producto la cantidad de la línea
        borrada.
    Si el número de orden de compra o el número de línea es incorrecto,
        se muestra un mensaje de error y se regresa al menú de órdenes de compra.
    */
    public void eliminarLineaOrden(int numeroOrden, int indiceLinea) throws Exception {
        OrdenCompra ordenCompra = obtenerOrdenCompra(numeroOrden);
        //Se debe sumar a las existencias del producto la cantidad de la línea
        //borrada.
        LineaOrdenCompra linea = ordenCompra.getLinea(indiceLinea);
        Producto producto = linea.getProducto();
        float cantidad = linea.getCantidad();
        producto.agregarExistencias(cantidad);
        //La linea se elimina de la orden de compra.
        ordenCompra.borrarLinea(indiceLinea);
    }
    /*
    Calcular total pendiente
    Al utilizar esta opción se muestra la suma del total de todas las órdenes que están marcadas
    como pendientes de pago. Sirve para saber cuánto dinero se le debe a la tienda en total
    */
    public float calcularTotalPendiente() {
        //Se crea un ArrayList de ordenes pendientes
        ArrayList<OrdenCompra> ordenesPendientes = new ArrayList();
        for (Cliente cliente : clientes) {
            //Se le agrega al ArrayList las ordenes pendientes de cada cliente
            ordenesPendientes.addAll( cliente.obtenerOrdenesPendientes() );
        }
        //Se calcula el total pendiente calculando el total de cada orden pendiente
        float resultado = 0;
        for (OrdenCompra orden : ordenesPendientes) {
            resultado += orden.calcularTotal();
        }
        return resultado;
    }

    /*
    Cambiar el estado de una orden a pendiente
    Se cambia el estado de una orden de cualquier estado a pendiente.
    NOTA: Todas las ordenes comienzan como iniciadas.
    */
    public void setOrdenPendiente(int numeroOrden) throws Exception {
        OrdenCompra ordenCompra = obtenerOrdenCompra(numeroOrden);
        ordenCompra.setEstado(EstadoCompra.PAGO_PENDIENTE);
    }
    /*
    Retorna el valor máximo de líneas en orden de compra
    */
    public int getMaxPos(int numeroOrden) throws Exception {
        OrdenCompra ordenCompra = obtenerOrdenCompra(numeroOrden);
        int pos = ordenCompra.getMaxPos();
        return pos;
    }
    
    /*
    Completar una orden
    Se cambia el estado de una orden de iniciada o pendiente a completada.
    NOTA: Todas las ordenes comienzan como iniciadas.
    */
    public void completarOrden(int numeroOrden) throws Exception {
        OrdenCompra ordenCompra = obtenerOrdenCompra(numeroOrden);
        ordenCompra.setEstado(EstadoCompra.COMPLETADA);
    }
    
    /*
    ----------------------------------------------------------------------------
    --------------------------PRODUCTOS-----------------------------------------
    ----------------------------------------------------------------------------
    */
    /*
    Ver lista de productos
    Muestra una lista con todos los productos registrados en el sistema.
    Por cada producto debe mostrarse código, nombre, cantidad en existencias,
    unidad de medida y precio
    */
    public ArrayList<String> verListaProductos() {
        ArrayList<String> resultado = new ArrayList();
        String res;
        for (Producto producto : productos) {
            resultado.add( producto.toString() );
        }
        return resultado;
    }
    
    public String verProducto(int codigoProducto) throws Exception {
        Producto producto = obtenerProducto(codigoProducto);
        return producto.toString();
    }
    /*
    Agregar producto
    Se pregunta al usuario que escriba nombre, precio, unidad de medida y
    cantidad inicial en existencias. Se crea el producto y se guarda en la
    lista de productos.
    */
    public int crearProducto(String nombre, float precio, String unidad, float existencias) {
        Producto producto = new Producto(nombre, precio, unidad, existencias);
        productos.add(producto);
        return producto.getCodigo();
    }
    /*
    Agregar existencias
    En esta opción el usuario puede agregar existencias al producto.
    Se muestra la lista de todos los productos para que el usuario vea el código
    de cada uno. Luego se lee el código del producto para agregar existencias.
    Si el código es válido, se pide que escriba la cantidad de existencias que
    desea agregar.
    Si el código no es válido,
        se muestra un mensaje de error y se regresa al menú de productos.
    */
    public void agregarExistenciasProducto(int codigoProducto, float nuevasExistencias) throws Exception {
        Producto producto = obtenerProducto(codigoProducto);
        producto.agregarExistencias(nuevasExistencias);
    }
    
    public float getExistencias(int codigoProducto) throws Exception {
        Producto producto = obtenerProducto(codigoProducto);
        float existencias = producto.getExistencias();
        return existencias;
    }
    
    
    public static WallRose CargarDatos() throws Exception {
        FileInputStream file = new FileInputStream("wallrose.data");
        ObjectInputStream stream = new ObjectInputStream(file);
        WallRose data = (WallRose)stream.readObject();
        int mayor =1;
        for (Cliente c: data.clientes) {
            if (c.getNumero()> mayor) {
                mayor = c.getNumero();
            }
        }
        Cliente.consecutivo = ++mayor;
        mayor = 1;
        for (OrdenCompra o : data.ordenes) {
            if (o.getNumero() > mayor) {
                mayor = o.getNumero();
            }
        }
        mayor = 1;
        for (Producto p : data.productos) {
            if (p.getCodigo() > mayor) {
                mayor = p.getCodigo();
            }
        }
        Producto.consecutivo = ++mayor;
        return data;
    }
    
    
    //FileOutputStream file: handler of the file
    
    
    public static void GuardarDatos(WallRose data) throws Exception {
        FileOutputStream file = new FileOutputStream("wallrose.data");
        ObjectOutputStream stream = new ObjectOutputStream(file);
        stream.writeObject(data);
        stream.close();
    }
    
}