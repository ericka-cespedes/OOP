/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tareawallrose;

import java.io.Serializable;
import java.util.Scanner;

/**
 *
 * @author erick
 */
public class TareaWallRose implements Serializable {

    /**
     * @param args the command line arguments
     */
    private static Scanner in = new Scanner(System.in);
    private static WallRose control = new WallRose();
    
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
        try{
            menuPrincipal();
            WallRose data = control.CargarDatos();
            control.GuardarDatos(data);
        }
        catch (Exception ex) {
            System.out.println( ex.toString() );
        }
    }
    /*
    ----------------------------------------------------------------------------
    ------------------------------MENUS-----------------------------------------
    ----------------------------------------------------------------------------
    */
    private static void menuPrincipal() throws Exception {
        System.out.println("Menú Principal");
        System.out.println("1 - Menú Clientes");
        System.out.println("2 - Menú Órdenes");
        System.out.println("3 - Menú Productos");
        System.out.println("4 - Exit");
        int numero = leerInt();
        OUTER:
        switch (numero) {
            case 1:
                menuClientes();
            case 2:
                menuOrdenes();
            case 3:
                menuProductos();
            case 4:
                break OUTER;
            default: menuPrincipal();
        }
    }
    private static void menuClientes() throws Exception {
        System.out.println("Menú Clientes");
        System.out.println("1 - Ver lista de clientes");
        System.out.println("2 - Agregar clientes");
        System.out.println("3 - Ver todas las órdenes");
        System.out.println("4 - Ver órdenes iniciadas");
        System.out.println("5 - Ver órdenes pendientes de pago");
        System.out.println("6 - Ver órdenes completadas");
        System.out.println("7 - Calcular total pendiente de un cliente");
        System.out.println("8 - Menú Principal");
        int numero = leerInt();
        switch (numero) {
            case 1:
                imprimirListaClientes();
                menuClientes();
            case 2: //Agregar cliente
                agregarCliente();
                menuClientes();
            case 3: //Ver todas las ordenes
                verOrdenesTodas();
                menuClientes();
            case 4: //Ver ordenes iniciadas
                verOrdenesIniciadas();
                menuClientes();
            case 5: //Ver ordenes pendientes
                verOrdenesPendientes();
                menuClientes();
            case 6: //Ver ordenes completas
                verOrdenesCompletadas();
                menuClientes();
            case 7 : //Calcular total pendiente
                calcularTotalPendienteCliente();
                menuClientes();
            case 8:
                menuPrincipal();
            default: menuClientes();
        }
    }
    private static void menuOrdenes() throws Exception {
        System.out.println("Menú Órdenes");
        System.out.println("1 - Ver lista de órdenes de compra");
        System.out.println("2 - Crear nueva órden de compra");
        System.out.println("3 - Agregar línea a una orden de compra");
        System.out.println("4 - Borrar línea de una orden de compra");
        System.out.println("5 - Calcular total pendiente");
        System.out.println("6 - Cambiar el estado de la orden a pago pendiente");
        System.out.println("7 - Completar orden");
        System.out.println("8 - Menú Principal");
        int numero = leerInt();
        switch (numero) {
            case 1: //Ver lista de órdenes de compra
                imprimirListaOrdenes();
                menuOrdenes();
            case 2: //Crear nueva órden de compra
                crearOrdenCompra();
                menuOrdenes();
            case 3: //Agregar línea a una orden de compra
                agregarLinea();
                menuOrdenes();
            case 4: //Borrar línea de una orden de compra
                borrarLinea();
                menuOrdenes();
            case 5: //Calcular total pendiente
                calcularTotalPendiente();
                menuOrdenes();
            case 6:
                setOrdenPendiente();
                menuOrdenes();
            case 7:
                completarOrden();
                menuOrdenes();
            case 8:
                menuPrincipal();
            default: menuOrdenes();
        }
    }
    private static void menuProductos() throws Exception {
        System.out.println("Menú Productos");
        System.out.println("1 - Ver lista de productos");
        System.out.println("2 - Agregar producto");
        System.out.println("3 - Agregar existencias");
        System.out.println("4 - Menú Principal");
        int numero = leerInt();
        switch (numero) {
            case 1: //Ver lista de productos
                imprimirListaProductos();
                menuProductos();
            case 2: //Agregar producto
                agregarProducto();
                menuProductos();
            case 3: //Agregar existencias
                agregarExistencias();
                menuProductos();
            case 4:
                menuPrincipal();
            default: menuProductos();
        }
    }
    
    /*
    ----------------------------------------------------------------------------
    ---------------------FUNCIONES REQUERIDAS-----------------------------------
    ----------------------------------------------------------------------------
    */
    private static void imprimirListaClientes() {
        System.out.println( control.verListaClientes() );
    }
    private static void imprimirListaOrdenes() {
        System.out.println( control.verListaOrdenes() );
    }
    private static void imprimirListaProductos() {
        System.out.println( control.verListaProductos() );
    }
    private static float leerFloat() throws Exception {
        float Float = in.nextFloat();
        if (Float >= 0) {
            return Float;
        }
        throw new Exception("No se pueden ingresar valores negativos.");
    }
    private static int leerInt() throws Exception {
        int Int = in.nextInt();
        if (Int >=0) {
            return Int;
        }
        throw new Exception("No se pueden ingresar valores negativos.");
    }
    private static String leerString() {
        String string = in.nextLine();
        return string;
    }
    
    /*
    ----------------------------------------------------------------------------
    --------------------------CLIENTES------------------------------------------
    ----------------------------------------------------------------------------
    */
    private static void agregarCliente() {
        /*
        b. Agregar cliente
        Se pide al usuario que escriba un nombre y un email.
        Se crea un cliente nuevo y se guarda en la lista de clientes.
        */
        System.out.println("Ingrese el nombre del cliente");
        leerString();
        String nombre = leerString();
        System.out.println("Ingrese el email del cliente");
        String email = leerString();
        control.agregarCliente(nombre, email);
    }
    private static void verOrdenesTodas() throws Exception {
        /*
        c. Ver todas las órdenes
        Primero se muestra la lista de los clientes registrados en el sistema para que el usuario vea el
        número de cada uno. Luego se pide al usuario que escriba un código de cliente. Si el código es
        válido, se muestra en pantalla la lista de todas las órdenes asociadas al cliente elegido. Para
        cada orden se muestra número, fecha, estado, líneas que la conforman, costo, monto por
        impuesto y total. Si el código no es válido, se muestra un mensaje de error y se regresa al menú
        de clientes.
        */
        try {
            imprimirListaClientes();
            System.out.println("Ingrese un código de cliente");
            int numero = leerInt();
            System.out.println("Todas las órdenes del cliente " + numero);
            System.out.println( control.obtenerOrdenesClienteTodas(numero) );
        }
        catch (Exception ex) {
            System.out.println( ex.toString() );
            menuClientes();
        }
        
        
    }
    private static void verOrdenesIniciadas() throws Exception {
        /*
        d. Ver órdenes iniciadas
        Similar a la opción anterior, pero la lista sólo contiene órdenes que se encuentran en estado
        iniciado.
        */
        try {
            imprimirListaClientes();
            System.out.println("Ingrese un código de cliente");
            int numero = leerInt();
            System.out.println("Todas las órdenes iniciadas del cliente " + numero);
            System.out.println( control.obtenerOrdenesClienteIniciadas(numero) );
        }
        catch (Exception ex) {
            System.out.println( ex.toString() );
            menuClientes();
        }
    }
    private static void verOrdenesPendientes() throws Exception {
        /*
        e. Ver órdenes pendientes de pago
        Similar a la opción anterior, pero la lista sólo contiene órdenes que se encuentran en estado
        pendiente de pago.
        */
        try {
            imprimirListaClientes();
            System.out.println("Ingrese un código de cliente");
            int numero = leerInt();
            System.out.println("Todas las órdenes pendientes del cliente " + numero);
            System.out.println( control.obtenerOrdenesClientePendientes(numero) );
        }
        catch (Exception ex) {
            System.out.println( ex.toString() );
            menuClientes();
        }
    }
    private static void verOrdenesCompletadas()  throws Exception {
        /*
        f. Ver órdenes completas
        Similar a la opción anterior, pero la lista sólo contiene órdenes que se encuentran en estado
        completa.
        */
        try {
            imprimirListaClientes();
            System.out.println("Ingrese un código de cliente");
            int numero = leerInt();
            System.out.println("Todas las órdenes completadas del cliente " + numero);
            System.out.println( control.obtenerOrdenesClienteCompletadas(numero) );
        }
        catch (Exception ex) {
            System.out.println( ex.toString() );
            menuClientes();
        }
    }
    private static void calcularTotalPendienteCliente() throws Exception{
        /*
        g. Calcular total pendiente de un cliente
        Se suma el costo de todas las órdenes
        */
        try {
            imprimirListaClientes();
            System.out.println("Ingrese un código de cliente");
            int numero = leerInt();
            System.out.println("Total pendiente del cliente " + numero);
            System.out.println( control.calcularTotalPendienteCliente(numero) );
        }
        catch (Exception ex) {
            System.out.println( ex.toString() );
            menuClientes();
        }
    }
    
    /*
    ----------------------------------------------------------------------------
    ---------------------ORDENES DE COMPRA--------------------------------------
    ----------------------------------------------------------------------------
    */
    private static void crearOrdenCompra() throws Exception {
        /*
        b. Crear nueva órden de compra
        Primero se muestra una lista con todos los clientes registrados para que el usuario vea el
        número de cada uno. Luego se pide que escriba el número de cliente al que se le quiere crear la
        orden de compra. Si el número de cliente es válido se crea una nueva orden de compra vacía, se
        agrega a la lista de órdenes de compra y se muestra un mensaje que indica que se creó
        correctamente y el número de la orden creada. Si el número de cliente no es válido, se muestra
        un mensaje de error y se regresa al menú de órdenes de compra.
        */
        try {
            imprimirListaClientes();
            System.out.println("Ingrese un código de cliente");
            int numero = leerInt();
            int orden = control.crearOrden(numero);
            System.out.println("La orden de compra se creó correctamente.");
            System.out.println("El número de la orden es " + orden);
        }
        catch (Exception ex) {
            System.out.println( ex.toString() );
            menuOrdenes();
        }
    }
    private static void agregarLinea() throws Exception {
        /*
        c. Agregar línea a una orden de compra
        Se muestra en pantalla una lista con todas las órdenes registradas en el sistema para que el
        usuario vea el número de cada una. Luego se pide al usuario que escriba un número de orden.
        Si el número de orden es válido, se muestra una lista con todos los productos registrados en el
        sistema para que el usuario vea el código de cada uno, se pide al usuario que escriba un código
        de producto y luego la cantidad de ese producto para agregar la línea en dicha orden de
        compra. Se debe restar de las existencias del producto la cantidad agregada en la línea.
        Sí el número de orden o el código del producto no es válido, se muestra un mensaje de error y
        se regresa al menú de órdenes de compra.
        */
        try {
            imprimirListaOrdenes();
            System.out.println("Ingrese un número de orden");
            int numero = leerInt();
            control.verOrden(numero);
            imprimirListaProductos();
            System.out.println("Ingrese un código de producto");
            int codigo = leerInt();
            control.verProducto(codigo);
            System.out.println("Ingrese la cantidad de ese producto");
            float cantidad = leerFloat();
            float existencias = control.getExistencias(codigo);
            if (cantidad <= existencias) {
                control.agregarLineaOrden(numero, codigo, cantidad);
            }
            throw new Exception("No hay existencias suficientes");
        }
        catch (Exception ex) {
            System.out.println( ex.toString() );
            menuOrdenes();
        }
    }
    private static void borrarLinea() throws Exception {
        /*
        d. Borrar línea de una orden de compra
        Se muestra en pantalla una lista con todas las órdenes registradas en el sistema para que el
        usuario vea el número de cada una. Luego se pide al usuario que escriba el número de orden. Si
        el número de orden es válido, se muestra la orden completa con todos sus detalles y líneas.
        Luego se pide al usuario que escriba el número de línea que desea borrar y se elimina de la
        orden de compra. Se debe sumar a las existencias del producto la cantidad de la línea borrada.
        Si el número de orden de compra o el número de línea es incorrecto, se muestra un mensaje de
        error y se regresa al menú de órdenes de compra.
        */
        try {
            imprimirListaOrdenes();
            System.out.println("Ingrese un número de orden");
            int numero = leerInt();
            control.verOrden(numero);
            System.out.println( control.verOrden(numero) );
            System.out.println("Ingrese el número de línea que desea borrar");
            int pos = leerInt();
            int maxPos = control.getMaxPos(numero);
            if (pos < maxPos) {
                control.eliminarLineaOrden(numero, pos);
            }
            throw new Exception("El número de línea no existe.");
        }
        catch (Exception ex) {
            System.out.println( ex.toString() );
            menuOrdenes();
        }
    }
    private static void calcularTotalPendiente() {
        /*
        e. Calcular total pendiente
        Al utilizar esta opción se muestra la suma del total de todas las órdenes que están marcadas
        como pendientes de pago. Sirve para saber cuánto dinero se le debe a la tienda en total.
        */
        System.out.println( control.calcularTotalPendiente() );
    }
    private static void setOrdenPendiente() throws Exception {
        try {
            System.out.println("Ingrese el número de orden");
            int numero = leerInt();
            control.setOrdenPendiente(numero);
        }
        catch (Exception ex) {
            System.out.println( ex.toString() );
            menuOrdenes();
        }
    }
    private static void completarOrden() throws Exception {
        try {
            System.out.println("Ingrese el número de orden");
            int numero = leerInt();
            control.completarOrden(numero);
        }
        catch (Exception ex) {
            System.out.println( ex.toString() );
            menuOrdenes();
        }
    }
    
    /*
    ----------------------------------------------------------------------------
    --------------------------PRODUCTOS-----------------------------------------
    ----------------------------------------------------------------------------
    */
    
    private static void agregarProducto() throws Exception {
        /*
        b. Agregar producto
        Se pregunta al usuario que escriba nombre, precio, unidad de medida y cantidad inicial en
        existencias. Se crea el producto y se guarda en la lista de productos.
        */
        try{
            System.out.println("Ingrese el nombre del producto");
            leerString();
            String nombre = leerString();
            System.out.println("Ingrese el precio del producto");
            float precio = leerFloat();
            System.out.println("Ingrese la unidad del producto");
            leerString();
            String unidad = leerString();
            System.out.println("Ingrese las existencias del producto");
            float existencias = leerFloat();
            control.crearProducto(nombre, precio, unidad, existencias);
        }
        catch (Exception ex) {
            System.out.println( ex.toString() );
            menuProductos();
        }
    }
    private static void agregarExistencias() throws Exception {
        /*
        c. Agregar existencias
        En esta opción el usuario puede agregar existencias al producto. Se muestra la lista de todos los
        productos para que el usuario vea el código de cada uno. Luego se lee el código del producto
        para agregar existencias. Si el código es válido, se pide que escriba la cantidad de existencias
        que desea agregar. Si el código no es válido, se muestra un mensaje de error y se regresa al
        menú de productos.
        */
        try {
            imprimirListaProductos();
            System.out.println("Ingrese el código del producto");
            int codigo = leerInt();
            control.verProducto(codigo);
            System.out.println("Ingrese las existencias del producto");
            float existencias = leerFloat();
            control.agregarExistenciasProducto(codigo, existencias);
        }
        catch (Exception ex) {
            System.out.println( ex.toString() );
            menuProductos();
        }
    }
}
