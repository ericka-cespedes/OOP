/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tareawallrose;

import java.io.Serializable;

/**
 *
 * @author ericka
 */
public enum EstadoCompra implements Serializable {
    INICIADA, PAGO_PENDIENTE, COMPLETADA;
    
    @Override
    public String toString() {
        switch(this) {
        case INICIADA: return "Iniciada";
        case PAGO_PENDIENTE: return "Pago pendiente";
        case COMPLETADA: return "Completada";
        default: throw new IllegalArgumentException();
        }
    }
}
