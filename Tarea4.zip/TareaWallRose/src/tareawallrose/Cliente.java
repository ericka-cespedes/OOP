/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tareawallrose;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author ericka
 */
public class Cliente implements Serializable {
    public static int consecutivo = 1;
    private int numero;
    private String nombre;
    private String email;
    private ArrayList<OrdenCompra> ordenes;
    
    /* Se pide al usuario que escriba un nombre y un email. Se crea un cliente
    nuevo y se guarda en la lista de clientes.*/
    public Cliente(String nombre, String email) {
        this.nombre = nombre;
        this.email = email;
        numero = consecutivo;
        consecutivo++;
        ordenes = new ArrayList();
    }
    //Setters y Getters
    public void setNumero(int numero) {
        this.numero = numero;
    }
    public int getNumero() {
        return numero;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getNombre() {
        return nombre;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getEmail() {
        return email;
    }
    
    public void agregarOrden(OrdenCompra orden) {
        ordenes.add(orden);
        //orden.setCliente(this);
        //orden.OrdenCompra(this);
    }
    /* Primero se muestra la lista de los clientes registrados en el sistema
    para que el usuario vea el número de cada uno.
    Luego se pide al usuario que escriba un código de cliente.
    Si el código es válido, se muestra en pantalla la lista de todas las órdenes
    asociadas al cliente elegido. Para cada orden se muestra número, fecha,
    estado, líneas que la conforman, costo, monto por impuesto y total.
    Si el código no es válido, se muestra un mensaje de error y se regresa al
    menú de clientes */
    public ArrayList obtenerOrdenesTodas() {
        return ordenes;
    }
    private ArrayList obtenerOrdenesFiltradas(EstadoCompra estado) {
        ArrayList<OrdenCompra> ordenesFiltradas = new ArrayList();
        for (OrdenCompra orden : ordenes) {
            EstadoCompra estadoOrden = orden.getEstado();
            if (estado == estadoOrden) {
                ordenesFiltradas.add(orden);
            }
        }
        return ordenesFiltradas;
    }
    /* Similar a obtenerOrdenesTodas(), pero la lista sólo contiene órdenes que
    se encuentran en estado iniciado. */
    public ArrayList obtenerOrdenesIniciadas() {
        return obtenerOrdenesFiltradas(EstadoCompra.INICIADA);
    }
    /* Similar a obtenerOrdenesTodas(), pero la lista sólo contiene órdenes que
    se encuentran en estado pendiente de pago. */
    public ArrayList obtenerOrdenesPendientes() {
        return obtenerOrdenesFiltradas(EstadoCompra.PAGO_PENDIENTE);
    }
    /* Similar a obtenerOrdenesTodas(), pero la lista sólo contiene órdenes que
    se encuentran en estado completado. */
    public ArrayList obtenerOrdenesCompletadas() {
        return obtenerOrdenesFiltradas(EstadoCompra.COMPLETADA);
    }
    /* Calcular total pendiente de un cliente
    Se suma el costo de todas las órdenes.
    */
    
    @Override
    /* Se muestra una lista con todos los clientes registrados en el sistema.
    Se muestra número, nombre y email. */
    public String toString() {
        String resultado = "Cuenta número:\t" + numero + "\t\t\t";
        resultado += "Cliente:\t" + nombre + "\t\t\t";
        resultado += "Email:\t" + email + "\n";
//        String resultado = "Cuenta número" + "\t\t\t\t" + "Cliente" + "\t\t\t\t" + "Email" + "\n";
//        resultado += "\t\t\t" + numero + "\t\t\t" + nombre + "\t\t\t" + email + "\n";
//        String resultado = "Cuenta número: " + numero + "\n";
//        resultado += "Cliente: " + nombre + "\n";
//        resultado += "Email: " + email + "\n";
        return resultado;
    }
}
