/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tareawallrose;

import java.io.Serializable;

/**
 *
 * @author ericka
 */
public class Producto implements Serializable {
    public static int consecutivo = 1;
    private int codigo;
    private String nombre;
    private float precio;
    private String unidad;
    private float existencias;
    
    public Producto(String nombre, float precio, String unidad, float existencias) {
        this.nombre = nombre;
        this.precio = precio;
        this.unidad = unidad;
        this.existencias = existencias;
        codigo = consecutivo;
        consecutivo++;
    }
    //Setters y Getters
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    public int getCodigo() {
        return codigo;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getNombre() {
        return nombre;
    }
    public void setPrecio(float precio) {
        this.precio = precio;
    }
    public float getPrecio() {
        return precio;
    }
    public void setUnidad(String unidad) {
        this.unidad = unidad;
    }
    public String getUnidad() {
        return unidad;
    }
    public void setExistencias(float existencias) {
        this.existencias = existencias;
    }
    public float getExistencias() {
        return existencias;
    }
    
    public void retirarExistencias(float cantidad) {
        existencias -= cantidad;
    }
    public void agregarExistencias(float cantidad) {
        existencias += cantidad;
    }
    @Override
    /*
    Ver lista de productos
    Muestra una lista con todos los productos registrados en el sistema.
    Por cada producto debe mostrarse código, nombre, cantidad en existencias,
    unidad de medida y precio.
    */
    public String toString() {
        String resultado;
        resultado = "Código del Producto: " + codigo + "\t\t\t";
        resultado += "Nombre: " + nombre + "\t\t\t";
        resultado += "Cantidad: " + existencias + "\t\t\t";
        resultado += unidad + "\t";
        resultado += precio + "\n";
        return resultado;
    }
}
