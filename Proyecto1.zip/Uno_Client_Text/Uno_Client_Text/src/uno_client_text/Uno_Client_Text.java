/*
    Esteban Ruiz Matamoros
    24/11/2018

    Clase principal
    Ejecuta la interfaz de consola
*/

package uno_client_text;

import java.util.Scanner;

public class Uno_Client_Text {
    public static void main(String[] args) {
        String data;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese su nick:");
        data = scanner.nextLine();
        EstadoJuego juego = new EstadoJuego(data);
        try {
            juego.SalaEspera();
        } catch (InterruptedException ex) {
            System.out.println("Hubo un error en el hilo de ejecucion.");
        }
    }
}
