/*
    Esteban Ruiz Matamoros
    24/11/2018

    JugadorSecundario
    Clase que representa a los clientes
    Jugador secundario se refiere a los jugadores que no son el líder.
    El jugador líder es la primera conexión al servidor y es el que decide cuándo comienza el juego.
*/

package uno_client_text;
public class JugadorSecundario {
    private String nick;
    private int ID;
    private int numeroCartas;

    public JugadorSecundario(String nick, int ID) {
        this.nick = nick;
        this.ID = ID;
        this.numeroCartas = 0;
    }

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }
    
    public int getNumeroCartas() {
        return numeroCartas;
    }

    public void setNumeroCartas(int numeroCartas) {
        this.numeroCartas = numeroCartas;
    }
}