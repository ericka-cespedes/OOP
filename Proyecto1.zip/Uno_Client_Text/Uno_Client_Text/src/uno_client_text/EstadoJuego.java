/*
    Esteban Ruiz Matamoros
    24/11/2018

    EstadoJuego
    Clase que conecta al servidor con el cliente para enviar el estado del juego.
*/

package uno_client_text;

import java.awt.AWTException;
import java.awt.Robot;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class EstadoJuego {
    private ArrayList<JugadorSecundario> jugadoresSecundarios;
    private ArrayList<Integer> mano;
    private ArrayList<String> cartasBase;
    private ServerConnection server;
    private int IDactual; //este es el jugador en turno
    private int IDjugador; //este soy yo
    private String nickJugador; //mi nick YO
    private int sizeMazo;
    private int sizeDescarte;
    private int IDcartaActual;
    private String datos;
    private int estado;
    
    public EstadoJuego(String nick){
        mano = new ArrayList();
        cartasBase = cartaFactory();
        jugadoresSecundarios = new ArrayList();
        estado = 1;
        try {
            server = new ServerConnection("192.168.1.4", 8888, nick);
        } catch (IOException ex) {
            throw new RuntimeException("Hubo un error conectandose con el servidor.", ex);
        }
        nickJugador = nick;
    }
    //Utilidades
    
    private String hexToAscii(String hexStr) {
        StringBuilder output = new StringBuilder("");
        for (int i = 0; i < hexStr.length(); i += 2) {
            String str = hexStr.substring(i, i + 2);
            output.append((char) Integer.parseInt(str, 16));
        }
        return output.toString();
    }
    
    public Queue<Character> stringToLinkedQueue(String datos){
        char [] dataChar = datos.toCharArray();
        Character [] dataCharacter  = new Character[dataChar.length];
        for (int i = 0; i < dataChar.length; i++) {
            dataCharacter[i] = dataChar[i];
        }
        Queue<Character> data = new LinkedList(Arrays.asList(dataCharacter));
        return data;
    }
    
    public void clear(){
        try {
            Robot pressbot = new Robot();
            pressbot.keyPress(17);
            pressbot.keyPress(76);
            pressbot.keyRelease(17);
            pressbot.keyRelease(76);
        } catch (AWTException ex) {
            System.out.println("No se pudo limpiar la consola.");
        }
    }
    
    public void sendMessage(String message){
        server.sendMessage(message);
    }
    
    public String readMessage() throws IOException{
        return server.readMessage();
    }
    
    private ArrayList<String> cartaFactoryAux(String color){
        ArrayList<String> temp = new ArrayList();
        for (int i = 0; i < 10; i++) {
            temp.add(color+" "+i);
        }
        temp.add(color+" Reversa");
        temp.add(color+" Salto");
        temp.add(color+" TomeDos");
        return temp;
    }
    
    private ArrayList<String> cartaFactory(){
        ArrayList<String> temp = new ArrayList();
        temp.addAll(cartaFactoryAux("Rojo"));
        temp.addAll(cartaFactoryAux("Verde"));
        temp.addAll(cartaFactoryAux("Amarillo"));
        temp.addAll(cartaFactoryAux("Azul"));
        temp.add("Negro Comodin");
        temp.add("Negro TomeCuatro");
        temp.add("Rojo Comodin");
        temp.add("verde Comodin");
        temp.add("Amarillo Comodin");
        temp.add("Azul Comodin");
        temp.add("Rojo TomeCuatro");
        temp.add("verde TomeCuatro");
        temp.add("Amarillo TomeCuatro");
        temp.add("Azul TomeCuatro");
        return temp;
    }
    
    public String estadoJuego(){
        String temp = "";
        if(estado == 1){
            temp = "Estado: Sala de Espera\n";
            temp += "Jugadores:\n";
            temp += nickJugador+"*\n";
            for(JugadorSecundario jugador : jugadoresSecundarios){
                temp += jugador.getNick()+"\n";
            }
            if(IDjugador == 1){
                temp += "Para iniciar la partida ingresa ff\n";
            }
        }else if(estado == 2){
            temp = "Estado: Jugando\n";
            temp += "Mazo: "+sizeMazo+"  Carta Actual: "+cartasBase.get(IDcartaActual)+"\n";
            String jugador = "";
            if(IDactual == IDjugador){
                jugador = nickJugador;
            }else{
                for(JugadorSecundario j : jugadoresSecundarios){
                    if(j.getID() == IDactual){
                        jugador = j.getNick();
                        break;
                    }
                }
            }
            temp += "En turno: "+jugador+"\n";
            temp += "Tu mano: \n";
            for(int id : mano){
                temp += cartasBase.get(id)+"("+Integer.toHexString(id)+")"+"\t";
            }
            temp += "\n";
            for(JugadorSecundario j : jugadoresSecundarios){
                temp += j.getNick()+": "+j.getNumeroCartas()+" cartas\t";
            }
            temp += "\n";
        }
        return temp;
    }
    
    //Juego
    
    public void SalaEspera() throws InterruptedException{
        try {
            datos = server.readMessage();
        } catch (IOException ex) {
            throw new RuntimeException("Hubo un error al leer el mensaje del servidor",ex);
        }
        Queue<Character> charArray = stringToLinkedQueue(datos);
        charArray.remove();
        while(charArray.remove() == '1'){
            int cantJugadores = Integer.parseInt(String.valueOf(charArray.remove()),16);
            IDjugador =  Integer.parseInt(String.valueOf(charArray.remove()), 16);
            jugadoresSecundarios.clear();
            for (int i = 0; i < cantJugadores; i++) {
                int vID =  Integer.parseInt(String.valueOf(charArray.remove()), 16);
                int vNickSize = Integer.parseInt(String.valueOf(charArray.remove()), 16);
                String nickTemp = "";
                for (int j = 0; j < vNickSize; j++) {
                    String valorHexa = String.valueOf(charArray.remove()) + String.valueOf(charArray.remove());
                    nickTemp += hexToAscii(valorHexa);
                }
                JugadorSecundario jugadorSec = new JugadorSecundario(nickTemp, vID);
                if(vID != IDjugador){
                    jugadoresSecundarios.add(jugadorSec);
                }
            }
            System.out.println(estadoJuego());
            Runnable runnable = () -> {
                Scanner scanner = new Scanner(System.in);
                String data = scanner.nextLine();
                if("ff".equals(data)){
                    server.sendMessage(data);
                }
            };
            Thread thread = new Thread(runnable);
            thread.start();
            try {
                datos = server.readMessage();
            } catch (IOException ex) {
                throw new RuntimeException("Hubo un error al leer el mensaje del servidor",ex);
            }
            charArray = stringToLinkedQueue(datos);
            charArray.remove();
        }
        estado = 2;
        jugando();
    }
    
    public void jugando() throws InterruptedException{
        Queue<Character> charArray = stringToLinkedQueue(datos);
        charArray.remove();
        while(charArray.remove() == '2'){
            sizeMazo = Integer.parseInt(String.valueOf(charArray.remove())+String.valueOf(charArray.remove()),16);
            sizeDescarte = Integer.parseInt(String.valueOf(charArray.remove())+String.valueOf(charArray.remove()),16);
            IDcartaActual = Integer.parseInt(String.valueOf(charArray.remove())+String.valueOf(charArray.remove()),16);
            IDactual =  Integer.parseInt(String.valueOf(charArray.remove()),16);
            IDjugador =  Integer.parseInt(String.valueOf(charArray.remove()),16);
            int canitdadCartas = Integer.parseInt(String.valueOf(charArray.remove())+String.valueOf(charArray.remove()),16);
            mano.clear();
            for (int i = 0; i < canitdadCartas; i++) {
                int carta = Integer.parseInt(String.valueOf(charArray.remove())+String.valueOf(charArray.remove()),16);
                mano.add(carta);
            }
            int cantidadJugadores =  Integer.parseInt(String.valueOf(charArray.remove()),16)-1;
            for (int i = 0; i < cantidadJugadores; i++) {
                int idJugador = Integer.parseInt(String.valueOf(charArray.remove()),16);
                System.out.println(jugadoresSecundarios.size());
                for(JugadorSecundario j : jugadoresSecundarios){
                    if(j.getID() == idJugador){
                        j.setNumeroCartas(Integer.parseInt(String.valueOf(charArray.remove())+String.valueOf(charArray.remove()),16));
                    }
                }
            }
            System.out.println(estadoJuego());
            if(IDjugador == IDactual){
                System.out.println("¿Que desea hacer?");
                System.out.println("1: Tomar una carta  2[IDcarta]: Jugar una carta  3: Pasar turno");
                String jugada;
                Scanner scanner = new Scanner(System.in);
                jugada = scanner.nextLine();
                server.sendMessage(jugada);
            }
            try {
                datos = server.readMessage();
                while(datos.startsWith("Va") || datos.startsWith("In")){
                    datos = server.readMessage();
                }
                if(datos.equals("Elija el color")){
                    System.out.println("Elija un color");
                    System.out.println("Rojo   Verde  Amarillo  Azul");
                    String color;
                    Scanner scanner = new Scanner(System.in);
                    color = scanner.nextLine();
                    server.sendMessage(color);
                    datos = server.readMessage();
                }
            } catch (IOException ex) {
                throw new RuntimeException("Hubo un error al leer el mensaje del servidor",ex);
            }
            charArray = stringToLinkedQueue(datos);
            charArray.remove();
        }
        estado = 3;
        ganador();
    }
    
    public void ganador(){
        System.out.println("Ha ganado: "+datos.substring(2));
    }
    
    //Setters | Getters

    public ArrayList<JugadorSecundario> getJugadoresSecundarios() {
        return jugadoresSecundarios;
    }

    public void setJugadoresSecundarios(ArrayList<JugadorSecundario> jugadoresSecundarios) {
        this.jugadoresSecundarios = jugadoresSecundarios;
    }

    public ArrayList<Integer> getMano() {
        return mano;
    }

    public void setMano(ArrayList<Integer> mano) {
        this.mano = mano;
    }

    public ServerConnection getServer() {
        return server;
    }

    public void setServer(ServerConnection server) {
        this.server = server;
    }

    public int getIDactual() {
        return IDactual;
    }

    public void setIDactual(int IDactual) {
        this.IDactual = IDactual;
    }

    public int getIDjugador() {
        return IDjugador;
    }

    public void setIDjugador(int IDjugador) {
        this.IDjugador = IDjugador;
    }

    public String getNickJugador() {
        return nickJugador;
    }

    public void setNickJugador(String nickJugador) {
        this.nickJugador = nickJugador;
    }

    public int getSizeMazo() {
        return sizeMazo;
    }

    public void setSizeMazo(int sizeMazo) {
        this.sizeMazo = sizeMazo;
    }

    public int getSizeDescarte() {
        return sizeDescarte;
    }

    public void setSizeDescarte(int sizeDescarte) {
        this.sizeDescarte = sizeDescarte;
    }

    public int getIDcartaActual() {
        return IDcartaActual;
    }

    public void setIDcartaActual(int IDcartaActual) {
        this.IDcartaActual = IDcartaActual;
    }

    public String getDatos() {
        return datos;
    }

    public void setDatos(String datos) {
        this.datos = datos;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }
    
    
}
