/*
Autores:
    Esteban Ruiz
    8/11/2018

    Clase que se encarga de crear las conecciones de los Sockets para los clientes
*/

package modelo;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Observable;
import java.util.logging.Level;
import java.util.logging.Logger;
public class Client_Connection extends Observable implements Runnable{
    private String nick;
    private final Socket socket;
    private final PrintWriter writer;
    private final BufferedReader reader;
    
    public Client_Connection(Socket socket) throws IOException{
        this.socket = socket;
        writer = new PrintWriter(socket.getOutputStream(), true);
        reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        nick = null;
    }
   
    @Override
    public void run(){
        while(nick == null && !socket.isClosed()){
            writer.println("00");
            try{
                nick = reader.readLine();
                setChanged();
                notifyObservers(nick);
            } catch (IOException ex) {
                Logger.getLogger(Client_Connection.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void sendMessage(String message) {
        writer.println(message);
    }
    public String readMessage() throws IOException {
        String message = reader.readLine();
        return message;
    }
    public void close() throws IOException {
        socket.close();
    }
    public String getName() {
        return nick;
    }
}
