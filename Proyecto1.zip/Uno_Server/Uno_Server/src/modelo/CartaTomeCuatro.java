/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.io.IOException;

/*
Autores:
    Ericka Céspedes
    10/11/2018

    Clase que representa las cartas come 4 
    Accíon especial: Jugador actual elige nuevo color de la pila de descarte, siguiente jugardor come 4 cartas y se salta al siguiente jugador
*/

public class CartaTomeCuatro extends Carta {
    //Constructor
    public CartaTomeCuatro(String texto, String color) {
        super(texto, color);
    }
    
    @Override
    public void accion() throws IOException {
        //Controladora -> saltarJugador(), darCartasSiguiente(4) y cambiarColorActual()
        Controller controler = Controller.getInstance();
        controler.setColor();
        controler.darCartasSiguiente(4);
        controler.siguienteTurno();
    }
}
