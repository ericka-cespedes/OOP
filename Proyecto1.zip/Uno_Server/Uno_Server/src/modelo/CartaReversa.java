/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/*
Autores:
    Ericka Céspedes
    10/11/2018

    Clase que representa las cartas reversa
    Accíon especial: Cambia el sentido de el orden de los turnos
*/

public class CartaReversa extends Carta {
    //Constructor
    public CartaReversa(String texto, String color) {
        super(texto, color);
    }
    
    @Override
    public void accion() {
        //Controladora -> invertir()
        Controller controler = Controller.getInstance();
        controler.invertir();
    }
}
