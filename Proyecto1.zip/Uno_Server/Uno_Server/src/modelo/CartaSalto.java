/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/*
Autores:
    Ericka Céspedes
    10/11/2018

    Clase que representa las cartas salto
    Accíon especial: Se salta el turno del siguiente jugardor
*/

public class CartaSalto extends Carta{
    //Constructor
    public CartaSalto(String texto, String color) {
        super(texto, color);
    }
    
    @Override
    public void accion() {
        //Controladora -> saltarJugador()
        Controller controler = Controller.getInstance();
        controler.siguienteTurno();
    }
}
