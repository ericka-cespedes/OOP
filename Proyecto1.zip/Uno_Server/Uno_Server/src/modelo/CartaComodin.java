/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.io.IOException;

/*
Autores:
    Ericka Céspedes
    10/11/2018

    Clase que representa las cartas de comodín
    Accíon especial: Cambia el color actual de la pila de descarte
*/

public class CartaComodin extends Carta {
    //Constructor
    public CartaComodin(String texto, String color) {
        super(texto, color);
    }
    
    @Override
    public void accion() throws IOException {
        //Controladora -> cambiarColorActual()
        Controller controler = Controller.getInstance();
        controler.setColor();
    }
    
}
