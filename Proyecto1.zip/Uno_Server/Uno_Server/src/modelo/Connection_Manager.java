/*
    Esteban Ruiz Matamoros
    8/11/2018
*/
package modelo;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Observable;
public class Connection_Manager extends Observable implements Runnable{
    private final int port;
    private final int maxConnections;
    private int connections;
    private boolean rConnections;
    private final ServerSocket server;
    
    public Connection_Manager(int port, int mClients) throws IOException {
        this.port = port;
        this.maxConnections = mClients;
        server = new ServerSocket(port);
        server.setSoTimeout(200);
        connections = 0;
        rConnections = true;
    }
    
    @Override
    public void run(){
        while(connections < maxConnections && rConnections){
            try {
                Socket socket = server.accept();
                Client_Connection client = new Client_Connection(socket);
                setChanged();
                notifyObservers(client);
                connections++;
            } catch (IOException ex) {
            }
            
        }
    }
    
    public void noAceptar(){
        rConnections = false;
    }
}
