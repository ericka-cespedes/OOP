package modelo;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Observable;
import java.util.Observer;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
Autores:
    Ericka Céspedes
    Esteban Ruiz
    Luis Villalta
    15/11/2018

    Clase que tiene la lógica del juego, las reglas dell juego y las ejecuta

*/

public class Controller implements Observer {
    private Connection_Manager cManager;
    private ArrayList<Jugador> jugadores; 
    private ArrayList<Carta> cartas;
    private ArrayList<Carta> mazo;
    private ArrayList<Carta> pilaDescarte;
    private CartaFactory factory;
    private boolean ganador; 
    private boolean reversa;
    private boolean start;
    private String winner;
    private int jugador_actual;
    
    private Controller (){
        try{
            cManager = new Connection_Manager(8888, 4);
        }catch (IOException ex){
             Logger.getLogger(Client_Connection.class.getName()).log(Level.SEVERE, null, ex);
        }
        jugadores = new ArrayList();
        ganador = false;
        reversa = true;
        start = false;
        jugador_actual = 0;
        factory = new CartaFactory();
        cartas = new ArrayList();
        mazo = new ArrayList();
        pilaDescarte = new ArrayList();
    }
    
    @Override
    public void update(Observable obj, Object arg){
        Client_Connection client = (Client_Connection) arg;
        Jugador jugador = new Jugador(client, this);
        jugador.setObserver();
        jugadores.add(jugador);
        Thread thread = new Thread(client);
        thread.start();
        System.out.println("Se ha unido un nuevo jugador");
        enviarSalaEspera();
    }
    
    public void inicializarJuego(){
        crearMazo();
        repartirCartas();
        Carta carta = mazo.remove(mazo.size()-1);
        while(carta.getTexto().equals("CambioColor") || carta.getTexto().equals("TomeCuatro")){
            mazo.add(0, carta);
            carta = mazo.remove(mazo.size()-1);
        }
        if(carta.getTexto().equals("Reversa") || carta.getTexto().equals("Salto")
            || carta.getTexto().equals("TomeDos")){
            jugador_actual = jugadores.size()-1;
        }
        try {
            carta.accion();
        } catch (IOException ex) {
            Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
        }
        pilaDescarte.add(carta);
        Collections.shuffle(mazo);
    }
    
    public void iniciarJuego(){
        while(!ganador){
            enviarEstado();
            Carta cartaActual = pilaDescarte.get(pilaDescarte.size()-1);
            String mensaje = jugadores.get(jugador_actual).leerMensaje();
            while(!jugar(mensaje, false)){
                enviarEstado();
                mensaje = jugadores.get(jugador_actual).leerMensaje();
            }
            ganador = (jugadores.get(jugador_actual).getCantidadCartas() == 0);
            winner = jugadores.get(jugador_actual).getNick();
            siguienteTurno();
            if(mazo.isEmpty()){
                reShuffle();
            }
        }
    }
    
    public void salaEspera(){
        while(!start){
            System.out.print("");
            if(jugadores.size() > 1 && jugadores.get(0).getNick() != null){
                String mensaje = jugadores.get(0).leerMensaje();
                if("ff".equals(mensaje)){
                    if(checkConnected()){
                        cManager.noAceptar();
                        start = true;
                        System.out.println(jugadores.get(0).getNick()+" ha iniciado la partida");
                    }else{
                        jugadores.get(0).enviarMensaje("NotConnected");
                    }
                }else{
                    jugadores.get(0).enviarMensaje("Invalid");
                }
            }
        }
    }
    
    @SuppressWarnings("empty-statement")
    public boolean jugar(String message, boolean used){
        if(message.startsWith("1") && !used){
            tomarCarta();
            enviarEstado();
            message = jugadores.get(jugador_actual).leerMensaje();
            while(!jugar(message, true)){
                enviarEstado();
                message = jugadores.get(jugador_actual).leerMensaje();
            };
            return true;
        }else{ 
            if(message.startsWith("2")){
                if(message.length() != 3){
                    throw new RuntimeException("Mensaje Invalido");
                }
                Jugador jugador = jugadores.get(jugador_actual);
                Carta carta = jugador.getCartaID(Integer.parseInt(message.substring(1), 16));
                if ((carta.getColor().equals(getColorActual())) 
                        || (carta.getTexto().equals(getTextoActual())) 
                        || ("negro".equals(carta.getColor()))) {
                    try {
                        pilaDescarte.add(carta);
                        carta.accion();
                        jugador.obtenerCartas().remove(carta);
                        jugador.enviarMensaje("Valid");
                        return true;
                    } catch (IOException ex) {
                        Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
                    }
                } else{
                    jugador.enviarMensaje("Invalid");
                    return false;
                }
            }else if(message.startsWith("3") && used){
                return true;
            }
        }
        return false;
    }
    
    public void enviarGanador(){
        System.out.println("Ha ganado: "+winner);
        for(Jugador jugador : jugadores){
            jugador.enviarMensaje("03"+ winner);
        }
    }
    
    public String getTextoActual(){
        return pilaDescarte.get(pilaDescarte.size()-1).texto; 
    }
    
    public boolean checkConnected(){
        for(Jugador jugador : jugadores){
            if(jugador.getNick() == null){
                return false;
            }
        }
        return true;
    }
    
    public void reShuffle(){
        mazo = pilaDescarte;
        for(Carta carta : mazo){
            if(carta.getTexto().equals("CambioColor")){
                carta.setColor("negro");
                carta.setID(52);
            }
            if(carta.getTexto().equals("TomeCuatro")){
                carta.setColor("negro");
                carta.setID(53);
            }
        }
        pilaDescarte = new ArrayList();
        Collections.shuffle(mazo);
        Carta carta = mazo.remove(mazo.size()-1);
        while(carta.getTexto().equals("CambioColor") || carta.getTexto().equals("TomeCuatro")){
            mazo.add(0, carta);
            carta = mazo.remove(mazo.size()-1);
        }
        try {
            carta.accion();
        } catch (IOException ex) {
            Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
        }
        pilaDescarte.add(carta);
    }
    
    public void repartirCartas(){
        for(int i=0; i<7; i++){
            jugadores.forEach((jugador) -> {
                jugador.agregarCarta(mazo.remove(mazo.size()-1));
            }); 
        }
    }
    
    public void siguienteTurno(){
        jugador_actual= (reversa) ? (jugador_actual-1):(jugador_actual+1)%jugadores.size();
        if(jugador_actual < 0){
            jugador_actual = jugadores.size()-1;
        }
    }
    
    private Jugador jugadorSiguiente(){
        int temp = (reversa) ? jugador_actual-1:(jugador_actual+1)%jugadores.size();
        if(temp < 0){
            temp = jugadores.size()-1;
        }
        return jugadores.get(temp);
    }
    
    public void crearMazo(){    
        cartas = factory.crearCartas();
        mazo.addAll(cartas);
        Collections.shuffle(mazo);
    }
    
    public void tomarCarta(){
       jugadores.get(jugador_actual).agregarCarta(mazo.remove(mazo.size()-1));
    }
    
    public String getColorActual(){
        return pilaDescarte.get(pilaDescarte.size()-1).color;
    }
    
    public void invertir() {
        this.reversa = !this.reversa;
    }
    
    public void setColor(){
        jugadores.get(jugador_actual).enviarMensaje("Elija el color");
        String color = jugadores.get(jugador_actual).leerMensaje();
        Carta carta = pilaDescarte.get(pilaDescarte.size()-1);
        carta.setColor(color);
    }
    
    public void darCartasSiguiente(int n){
        Carta carta; // carta se agregara a la mano del jugador.
        for(int i = 0; i < n; i++){
            carta = mazo.remove(mazo.size() - 1);
            jugadorSiguiente().obtenerCartas().add(carta);
        }
    }
    
    public void enviarEstado(){
        for(Jugador jugador : jugadores){
            String temp = "02";
            String size = Integer.toHexString(mazo.size());
            if(size.length() == 1){
                size = "0"+size;
            }
            temp += size;
            size = Integer.toHexString(pilaDescarte.size());
            if(size.length() == 1){
                size = "0"+size;
            }
            temp += size;
            temp += pilaDescarte.get(pilaDescarte.size()-1).toString();
            temp += Integer.toHexString(jugador_actual+1);
            temp += jugador.toString();
            temp += Integer.toHexString(jugadores.size());
            for(Jugador player : jugadores){
                if(player != jugador){
                    temp += Integer.toHexString(player.getID());
                    size = Integer.toHexString(player.getCantidadCartas());
                    if(size.length() == 1){
                        size = "0"+size;
                    }
                    temp += size;
                }
            }
            jugador.enviarMensaje(temp);
        }
    }
    
    public void enviarSalaEspera(){
        for(Jugador jugador : jugadores){
            if(jugador.getNick()!=null){
                String temp;
                temp = "01" + Integer.toHexString(jugadores.size());
                temp += Integer.toHexString(jugador.getID());
                for(Jugador player : jugadores){
                    String nick = (player.getNick() == null) ? "Cargando..." : player.getNick();
                    temp += Integer.toHexString(player.getID());
                    temp += Integer.toHexString(nick.length());
                    for(char car : nick.toCharArray()){
                        int val = Integer.valueOf(car);
                        String tempChar = Integer.toHexString(val);
                        if(tempChar.length() == 1){
                            tempChar = "0"+tempChar;
                        }
                        temp += tempChar;
                    }
                }
                jugador.enviarMensaje(temp);
            }
        }
    }
    
    public void startManager(){
        cManager.addObserver(this);
        Thread thread = new Thread(cManager);
        thread.start();
    }
    
    public static Controller getInstance() {
        return ControlerHolder.INSTANCE;
    }
    
    private static class ControlerHolder {
        private static final Controller INSTANCE = new Controller();
    }
    public boolean getStart(){
        return start;
    }
    private Jugador getJugadorActual(){
        return jugadores.get(jugador_actual);
    }
}
