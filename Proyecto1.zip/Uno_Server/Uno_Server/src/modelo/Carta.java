/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.io.IOException;

/**
 *
 * @author erick
 */
public abstract class Carta {
    public static int numero = 0;
    protected int ID;
    protected String texto;
    protected String color;
    
    public Carta(String texto, String color) {
        this.texto = texto;
        this.color = color;
        ID = numero++;
    }
    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public String getColor() {
        return color;
    }
    public int getID(){
        return ID;
    }
    public void setID(int ID){
        this.ID = ID;
    }

    public void setColor(String color) {
        this.color = color;
        int sum = 0;
        if("TomeCuatro".equals(texto)){
            sum = 3;
        }
        switch (color){
            case "Rojo":
                ID += 2+sum;
                break;
            case "Verde":
                ID += 3+sum;
                break;
            case "Amarillo":
                ID += 4+sum;
                break;
            case "Azul":
                ID += 5+sum;
                break;
        }
    }
    
    @Override
    public String toString(){
        String val = Integer.toHexString(ID);
        if(val.length()== 1) val = "0"+val;
        return val;
    }
    
    public abstract void accion() throws IOException;
}
