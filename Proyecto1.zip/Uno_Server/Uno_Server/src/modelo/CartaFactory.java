/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.ArrayList;

/*
Autores:
    Ericka Céspedes
    María Fernanda Niño
    Luis Villata
    12/11/2018

    Clase que se encarga de crear el mazo de cartas
*/

public class CartaFactory {
    private ArrayList<Carta> cartas = new ArrayList();
    
    public ArrayList<Carta> crearCartas(){
        crearCartasColores("Rojo");
        crearCartasColores("Verde");
        crearCartasColores("Amarillo");
        crearCartasColores("Azul");
        crearComodines();
        return cartas;
    }
    
    private void crearCartasColores(String color){
        Carta carta, cartaReversa, cartaSalto, cartaTomeDos;
        carta = new CartaNumero("0",color);
        cartas.add(carta);
        for (int i = 1; i <= 9; i++) {
            carta = new CartaNumero(String.valueOf(i), color);
            cartas.add(carta);
            cartas.add(carta);
        }
        cartaReversa = new CartaReversa("Reversa", color);
        cartaSalto = new CartaSalto("Salto", color);
        cartaTomeDos = new CartaTomeDos("TomeDos", color);
        
        for (int i = 0; i < 2; i++) {
            cartas.add(cartaReversa);
            cartas.add(cartaSalto);
            cartas.add(cartaTomeDos);
        }
    }
    
    private void crearComodines(){
        Carta cartaComodin;
        Carta cartaTomeCuatro;
        for (int i = 0; i < 4; i++) {
            cartaComodin = new CartaComodin("CambioColor", "negro");
            cartaComodin.setID(52);
            cartas.add(cartaComodin);
            cartaTomeCuatro = new CartaTomeCuatro("TomeCuatro", "negro");
            cartaTomeCuatro.setID(53);
            cartas.add(cartaTomeCuatro);
        }
    }    
}