/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.io.IOException;

/*
Autores:
    Ericka Céspedes
    10/11/2018

    Clase que representa las cartas tome 2 
    Accíon especial: Siguiente jugardor come 2 cartas y se salta al siguiente jugador

*/

public class CartaTomeDos extends Carta {
    //Constructor
    public CartaTomeDos(String texto, String color) {
        super(texto, color);
    }
    
    @Override
    public void accion() throws IOException {
        //Controladora -> saltarJugador() y darCartasSiguiente(2)
        Controller controler = Controller.getInstance();
        controler.darCartasSiguiente(2);
        controler.siguienteTurno();
    }
}
