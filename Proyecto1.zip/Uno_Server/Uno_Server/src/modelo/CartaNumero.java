/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/*
Autores:
    Ericka Céspedes
    10/11/2018

    Clase que representa las cartas de número
    Accíon especial: Ninguna
*/

public class CartaNumero extends Carta {
    //Constructor
    public CartaNumero(String texto, String color) {
        super(texto, color);
    }
    
    @Override
    public void accion() {
        //Nada
    }
}
