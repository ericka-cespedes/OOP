/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;
/*
Autores:
    Ericka Céspedes
    Esteban Ruiz
    Luis Villalta
    15/11/2018

    Clase que crea los Jugadores con una conección y un controlador
*/
public class Jugador implements Observer{
    public static int numero = 0;
    private final int ID;
    private String nick;
    private ArrayList<Carta> cartas;
    private final boolean leader;
    private final Client_Connection connection;
    private final Controller controller;
    
    //Constructor
    public Jugador(Client_Connection connection, Controller controller) {
        this.nick = null;
        cartas = new ArrayList();
        this.connection = connection;
        this.controller = controller;
        ID = ++numero;
        leader = ID == 1;
    }
    //Setters y Getters
    public void setNick(String nick) {
        this.nick = nick;
    }
    public String getNick() {
        return nick;
    }
    public int getCantidadCartas() {
        return cartas.size();
    }
    public boolean getLeader(){
        return leader;
    }
    public int getID(){
        return ID;
    }
    public void setObserver(){
        connection.addObserver(this);
    }
    @Override
    public String toString(){
        String val =  Integer.toHexString(ID);
        String temp = Integer.toHexString(cartas.size());
        if(temp.length() == 1){
            temp = "0"+temp;
        }
        val += temp;
        for(Carta carta : cartas){
            val += carta.toString();
        }
        return val;
    }
    //Otros metodos
    @Override
    public void update(Observable o, Object arg) {
        nick = (String) arg;
        controller.enviarSalaEspera();
        System.out.println("El cliente "+ID+" Cambio su nick a: "+nick);
    }
    
    public void agregarCarta(Carta carta){
        cartas.add(carta);
    }
    public ArrayList<Carta> obtenerCartas() {
        return cartas;
    }
    public Carta quitarCarta(int i) {
        Carta carta = cartas.remove(i);
        return carta;
    }
    public Carta getCartaID(int id){
        for(Carta carta : cartas){
            if(carta.ID == id){
                return carta;
            }
        }
        return null;
    }
    
    public void enviarMensaje(String mensaje){
        connection.sendMessage(mensaje);
    }
    public String leerMensaje(){
        String message = "";
        try{
            message = connection.readMessage();
        }catch (IOException ex){
            System.out.println("Hubo un error al recibir el mensaje");
        }
        return message;
    }
    public void cerrarConexion() throws IOException{
        connection.close();
    }
}
