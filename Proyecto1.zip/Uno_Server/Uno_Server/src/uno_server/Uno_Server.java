/*
    Esteban Ruiz Matamoros
    8/11/2018

    Clase que ejecuta el main
    Inicializa el controlador
    Es el servidor
*/
package uno_server;
import modelo.Controller;
public class Uno_Server {
    public static void main(String[] args) {
        Controller controlador = Controller.getInstance();
        controlador.startManager();
        controlador.salaEspera();
        controlador.inicializarJuego();
        controlador.iniciarJuego();
        controlador.enviarGanador();
    }
    
}
