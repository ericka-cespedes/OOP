/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uno_vista;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

/**
 *
 * @author マリアフェルナンダ
 */
public class ViewControler {
    
    boolean primeraVez = true;
    String dat = "";
    String ultimoString;
    private ArrayList<JugadorSecundario> jugadoresSecundarios;
    private ArrayList<Integer> mano;
    private ServerConnection server;
    private int IDactual; //este es el jugador en turno
    private int IDjugador; //este soy yo
    private String nickJugador; //mi nick YO
    private int sizeMazo;
    private int sizeDescarte;
    private int IDcartaActual;
    private int estado;

    public ViewControler() {
        this.jugadoresSecundarios = new ArrayList();
        this.mano = new ArrayList();
        estado = 1;
    }
    
    
    private String hexToAscii(String hexStr) {
    StringBuilder output = new StringBuilder("");
     
    for (int i = 0; i < hexStr.length(); i += 2) {
        String str = hexStr.substring(i, i + 2);
        output.append((char) Integer.parseInt(str, 16));
    }
     
    return output.toString();
}
    
    public void iniciarJuego(ViewControler control) throws IOException, InterruptedException{
        Uno_1 juego = new Uno_1();
        juego.setController(control);
        juego.setVisible(true);
        Object o = juego.getTextArea();
        JTextArea txt = null; //null por ahora, es para prueba
        if(txt instanceof java.lang.Object){
            txt = JTextArea.class.cast(o);
        }
        /*
        Runnable runnable = () -> {try {
            actualizarEstadoJuego(null);
            } catch (IOException ex) {
                Logger.getLogger(ViewControler.class.getName()).log(Level.SEVERE, null, ex);
            } catch (InterruptedException ex) {
                Logger.getLogger(ViewControler.class.getName()).log(Level.SEVERE, null, ex);
            }
}; //esto es para hacer un obj ejecutable en otro hilo (es lambda (ejecutable en otro hilo))
        Thread thread = new Thread(runnable); // se crea el hilo y se le pasa el ejecutable (runnable)
        thread.start();
        
        
        */
        
        
       // actualizarEstadoJuego(txt);
       /* 
        
                Runnable runnable = () -> {try {
            System.out.println("");
                    actualizarEstadoJuego(null);
            
            } catch (IOException ex) {
                Logger.getLogger(ViewControler.class.getName()).log(Level.SEVERE, null, ex);
            } catch (InterruptedException ex) {
                Logger.getLogger(ViewControler.class.getName()).log(Level.SEVERE, null, ex);
            }
        }; 
        Thread thread = new Thread(runnable);
        thread.start();
        */
    }
    
    public Queue<Character> stringToLinkedQueue(String datos){
        char [] dataChar = datos.toCharArray();
        Character [] dataCharacter  = new Character[dataChar.length];
        for (int i = 0; i < dataChar.length; i++) {
            dataCharacter[i] = dataChar[i];
        }
        Queue<Character> data = new LinkedList(Arrays.asList(dataCharacter));
        System.out.println("data - " + data);
        return data;
    }
    
    public void actualizarSalaEspera(JTextArea jtxtarea, JButton btnInicioPartida){
        try{
            System.out.println("asdasd");
            System.out.println(server);
            String datos = server.readMessage();
            System.out.println(datos);
    //        char [] dataChar = datos.toCharArray();
    //        Character [] dataCharacter  = new Character[dataChar.length];
    //        for (int i = 0; i < dataChar.length; i++) {
    //            dataCharacter[i] = dataChar[i];
    //        }
            Queue<Character> data = stringToLinkedQueue(datos);
            data.remove();
            while(data.remove() == '1'){

                int cantJugadores = Integer.parseInt(String.valueOf(data.remove()),16);
                IDjugador =  Integer.parseInt(String.valueOf(data.remove()), 16);
                jugadoresSecundarios.clear();
                for (int i = 0; i < cantJugadores; i++) {
                    int vID =  Integer.parseInt(String.valueOf(data.remove()), 16);
                    int vNickSize = Integer.parseInt(String.valueOf(data.remove()), 16);
                    String nickTemp = "";
                    for (int j = 0; j < vNickSize; j++) {
                        String valorHexa = String.valueOf(data.remove()) + String.valueOf(data.remove());
                        nickTemp += hexToAscii(valorHexa);
                    }
                    JugadorSecundario jugadorSec = new JugadorSecundario(nickTemp, vID);
                    if(vID != IDjugador){
                        jugadoresSecundarios.add(jugadorSec);
                    }
                }
                //esto pone en la pantalla el nombre de los jugadores
                if(!jtxtarea.getText().equals(salaEsperaToString())){
                    jtxtarea.setText(salaEsperaToString());
                }
                //con esto se bloquea el boton en caso de que el jugador no sea lider para uqe no pueda iniciar la partida
                if(IDjugador == 1){
                    btnInicioPartida.setEnabled(true);
                } else {
                    btnInicioPartida.setEnabled(false);
                }
                jtxtarea.setText(salaEsperaToString());
                datos = server.readMessage();
                ultimoString = datos;///ultima captura en salaEspera
                data = stringToLinkedQueue(datos);
                data.remove();
            }
        }catch (IOException ex){
        }
        try {
            iniciarJuego(this);
        } catch (InterruptedException | IOException ex) {
            Logger.getLogger(ViewControler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void actualizarEstadoJuego(JLabel cartaActual) throws IOException, InterruptedException{
//        Runnable runnable = () -> {try {
//            System.out.println("");
//            dat = server.readMessage();
//            System.out.println("el print del hilo :v --> " + dat);
//            } catch (IOException ex) {
//                Logger.getLogger(ViewControler.class.getName()).log(Level.SEVERE, null, ex);
//            }
//        }; 
//        Thread thread = new Thread(runnable);
//        thread.start();
       // String datos;
//        try{
//            datos = server.readMessage();    
//        }catch(Exception ex){
            //datos = ultimoString;
        //}
        
        //para probar el ultimo string guardado en la sala de espera..
        String datos;
        if(primeraVez){
            datos = ultimoString;
            System.out.println("el ultimo string de la sala de espera: " + ultimoString);
            primeraVez = false;
        } else {
            datos = server.readMessage();
            ultimoString = datos; //para guardarlo todo el tiempo y acceder a el mas facil desde el juego
        }
        
        Queue<Character> data = stringToLinkedQueue(datos);
        data.remove();
        while(data.remove() == '2'){
            sizeMazo = Integer.parseInt(String.valueOf(data.remove())+String.valueOf(data.remove()),16);
            sizeDescarte = Integer.parseInt(String.valueOf(data.remove())+String.valueOf(data.remove()),16);
            IDcartaActual = Integer.parseInt(String.valueOf(data.remove())+String.valueOf(data.remove()),16);
            IDactual =  Integer.parseInt(String.valueOf(data.remove()),16);
            IDjugador =  Integer.parseInt(String.valueOf(data.remove()),16);
            int canitdadCartas = Integer.parseInt(String.valueOf(data.remove())+String.valueOf(data.remove()),16);
            mano.clear();
           // System.out.println("entra");
            for (int i = 0; i < canitdadCartas; i++) {
                int carta = Integer.parseInt(String.valueOf(data.remove())+String.valueOf(data.remove()),16);
                mano.add(carta);
            }
            int cantidadJugadores =  Integer.parseInt(String.valueOf(data.remove()),16)-1;
            for (int i = 0; i < cantidadJugadores; i++) {
                int idJugador = Integer.parseInt(String.valueOf(data.remove()),16);
                System.out.println(jugadoresSecundarios.size());
                for(JugadorSecundario j : jugadoresSecundarios){
                    if(j.getID() == idJugador){
                        j.setNumeroCartas(Integer.parseInt(String.valueOf(data.remove())+String.valueOf(data.remove()),16));
                    }
                }
            }
            
            ////
            
            String ret = "(" + nickJugador + ") tengo " + mano.size() + " cartas.\n\n";
        
            for(JugadorSecundario j : jugadoresSecundarios){
                ret = ret + "Jugador " + j.getID() + ": " + j.getNick() + "\nCantidad de Cartas: " + j.getNumeroCartas() + "\n\n";
            }
            //Thread.sleep(10);
            cartaActual.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/"+IDcartaActual+".png")));
            
            
            ////
            datos = server.readMessage();
            data = stringToLinkedQueue(datos);
            data.remove();
            
        }
        
        System.out.println("no entro");
    }
    
    public String salaEsperaToString(){
        String ret = nickJugador+"\n";
        for(JugadorSecundario jugador : jugadoresSecundarios){
            ret += jugador.getNick() + "\n";
        }
        return ret;
    }
    
    public ArrayList<JugadorSecundario> getJugadoresSecundarios() {
        return jugadoresSecundarios;
    }

    public ArrayList<Integer> getMano() {
        return mano;
    }

    public ServerConnection getServer() {
        return server;
    }

    public void setServer(String nick) throws IOException {
        this.server = new ServerConnection("192.168.1.2", 8888, nick);
        this.nickJugador = nick;
    }

    public int getIDactual() {
        return IDactual;
    }

    public void setIDactual(int IDactual) {
        this.IDactual = IDactual;
    }

    public int getIDjugador() {
        return IDjugador;
    }

    public void setIDjugador(int IDjugador) {
        this.IDjugador = IDjugador;
    }

    public String getNickJugador() {
        return nickJugador;
    }

    public void setNickJugador(String nickJugador) {
        this.nickJugador = nickJugador;
    }

    public int getSizeMazo() {
        return sizeMazo;
    }

    public void setSizeMazo(int sizeMazo) {
        this.sizeMazo = sizeMazo;
    }

    public int getSizeDescarte() {
        return sizeDescarte;
    }

    public void setSizeDescarte(int sizeDescarte) {
        this.sizeDescarte = sizeDescarte;
    }

    public int getIDcartaActual() {
        return IDcartaActual;
    }

    public void setIDcartaActual(int IDcartaActual) {
        this.IDcartaActual = IDcartaActual;
    }
    
    

    
    
    
    
    
    
}
