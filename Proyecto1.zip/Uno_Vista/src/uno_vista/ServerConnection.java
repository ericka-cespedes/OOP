/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uno_vista;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

/**
 *
 * @author マリアフェルナンダ
 */
public class ServerConnection {

    private int port;
    private String IP;
    private Socket socket;
    private PrintWriter writer;
    private BufferedReader reader;
    String name;

    public ServerConnection(String IP, int port, String name) throws IOException {
        this.IP = IP;
        this.port = port;
        socket = new Socket(IP, port);
        writer = new PrintWriter(socket.getOutputStream(), true);
        reader = new BufferedReader(
                new InputStreamReader(socket.getInputStream()));
        this.name = name;
        String msg = readMessage();
        if (msg.equals("00")) {
            sendMessage(name);
        }
    }

    public void setName(String name) {
        this.name = name;
    }

    public void sendMessage(String message) {
        writer.println(message);
    }

    public  synchronized String readMessage() throws IOException {
        return reader.readLine();
    }

    public void close() throws IOException {
        socket.close();
    }
}
