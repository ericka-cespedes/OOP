/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uno_vista;

/**
 *
 * @author マリアフェルナンダ
 */
public class JugadorSecundario {
    private String nick;
    private int ID;
    private int numeroCartas;

    public JugadorSecundario(String nick, int ID) {
        this.nick = nick;
        this.ID = ID;
        this.numeroCartas = 0;
    }

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }
    
    public int getNumeroCartas() {
        return numeroCartas;
    }

    public void setNumeroCartas(int numeroCartas) {
        this.numeroCartas = numeroCartas;
    }
    
    
    
}
