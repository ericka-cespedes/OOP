import socket
import codecs
from time import sleep

Comodines = ["Comodin", "+4", "Comodin Rojo", "Comodin Verde", "Comodin Amarillo", "Comodin Azul"
            ,"+4 Rojo", "+4 Verde", "+4 Amarillo", "+4 Azul"]

cartas = []

class Carta:
    def __init__(self, color, texto):
        self.color = color
        self.texto = texto

    def toString(self):
        return self.color+" "+self.texto

def cartasFactory():
    def cartaColor(color):
        for i in range(10):
            cartas.append(Carta(color, str(i)))
        cartas.append(Carta("Reversa", color))
        cartas.append(Carta("Salto", color))
        cartas.append(Carta("+2", color))
    cartaColor("Rojo")
    cartaColor("Verde")
    cartaColor("Amarillo")
    cartaColor("Azul")

def numeroToCarta(numero):
    print("Numero de carta: ", numero)
    if numero > 51:
        return Comodines[numero-52]
    return cartas[numero].toString()



class SalaEspera:
    def __init__(self):
        self.cantidadJugadores = 0
        self.ID = 0
        self.jugadores = []

    def actualizar(self, data):
        self.cantidadJugadores = int(data[:1], 16)
        data = data[1:]
        self.ID = int(data[:1], 16)
        data = data[1:]
        self.jugadores = []
        for i in range(self.cantidadJugadores):
            id = int(data[:1], 16)
            data = data[1:]
            nick = ""
            sizeNick = int(data[:1], 16)
            data = data[1:]
            for j in range(sizeNick):
                nick += chr(int(data[:2], 16))
                data = data[2:]
            self.jugadores.append((id, nick))

    def toString(self):
        string = f"Cantidad de jugadores: {self.cantidadJugadores}\n"
        string += f"Su ID: {self.ID}\n"
        for jugador in self.jugadores:
            string += f"Jugador {jugador[0]}: {jugador[1]}\n"
        return string

class Juego:
    def __init__(self):
        self.sizeMazo = 0
        self.sizePila = 0
        self.cartaActual = 0
        self.jugadorActual = 0
        self.ID = 0
        self.cartas = []
        self.jugadores = []

    def actualizar(self, data):
        self.sizeMazo = int(data[:2], 16)
        data = data[2:]
        self.sizePila = int(data[:2], 16)
        data = data[2:]
        self.cartaActual = numeroToCarta(int(data[:2], 16))
        data = data[2:]
        self.jugadorActual = int(data[:1], 16)
        data = data[1:]
        self.ID = int(data[:1], 16)
        data = data[1:]
        cantidadCartas = int(data[:2], 16)
        data = data[2:]
        self.cartas = []
        for carta in range(cantidadCartas):
            self.cartas.append(numeroToCarta(int(data[:2], 16))+"("+str(data[:2])+")")
            data = data[2:]
        cantidadJugadores = int(data[:1], 16)-1
        data = data[1:]
        self.jugadores = []
        for jugador in range(cantidadJugadores):
            id = int(data[:1], 16)
            data = data[1:]
            cantidad = int(data[:2], 16)
            data = data[2:]
            self.jugadores.append((id, cantidad))

    def toString(self):
        string = f"Tamaño del mazo: {self.sizeMazo}\n"
        string += f"Tamaño de descarte: {self.sizePila}\n"
        string += f"Carta actual: {self.cartaActual}\n"
        string += f"Jugador actual: {self.jugadorActual}\n"
        string += f"Tu ID: {self.ID}\n"
        string += "Tu mano:"
        for carta in self.cartas:
            string += f"  {carta}"
        string += "\n"
        for jugador in self.jugadores:
            string += f"Jugador {jugador[0]} tiene {jugador[1]} cartas"
        return string


HOST = "192.168.1.2"
PORT = 8888

cartasFactory()

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((HOST, PORT))

data = s.recv(1024)

while data[:2] != b"00":
    data = s.recv(1024)
nick = input("Ingrese su nick: ")
s.sendall(str.encode(nick+"\n"))

sala = SalaEspera()
x = False
while data[:2] != b"02":
    data = s.recv(1024)
    dataDecod = data.decode('utf-8')
    string = ""
    if dataDecod[:2] == "01":
        string = "Estado: Sala de espera\n"
        dataDecod = dataDecod[2:]
    sala.actualizar(dataDecod)
    print(string+sala.toString())
    if sala.ID == 1 and not x:
        x = True
        s.sendall(str.encode(input("ff to start(?) ")+"\n"))


sala = Juego()
while data[:2] != b"03":
    dataDecod = data.decode('utf-8')
    string = ""
    if dataDecod[:2] == "02":
        string = "Estado: Jugando\n"
        dataDecod = dataDecod[2:]
    sala.actualizar(dataDecod)
    print(string+sala.toString())
    if sala.jugadorActual == sala.ID:
        s.sendall(str.encode(input("Lo que haras: ")+"\n"))
    data = s.recv(1024)
    if data[:2] == b"El":
        s.sendall(str.encode(input("Elija un color: ")+"\n"))
        data = s.recv(1024)
    if data[:2] == b"Va" or data[:2] == b"In":
        data = s.recv(1024)


print("HA GANADO: ", data[2:].decode("utf-8"))
