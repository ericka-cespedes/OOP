/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ericka.cespedes.tarea2;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ericka
 */
public class ErickaCespedesTarea2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
    /*
    Para probar el funcionamiento de la clase cuenta, cree un método main en la
    clase aplicación donde se declare una colección de cuentas (puede ser
    ArrayList) y se agreguen diferentes instancias (mínimo 8). Con cada
    instancia pruebe invocar los diferentes métodos programados en la clase para
    corroborar su correcto funcionamiento. Finalmente, recorra la colección
    invocando el método toString de cada cuenta e imprimiendo el contenido de
    cada una en pantalla.
    */
        // TODO code application logic here
        ArrayList<Cuenta> cuentas = new ArrayList<>();
        cuentas.add(new Cuenta("Cliente1",1000));
        cuentas.add(new Cuenta("Cliente2",1000));
        cuentas.add(new Cuenta("Cleinte3"));
        cuentas.add(new Cuenta("Cliente4"));
        cuentas.add(new Cuenta("Cliente5"));
        cuentas.add(new Cuenta("Cliente6"));
        cuentas.add(new Cuenta("Cliente7"));
        cuentas.add(new Cuenta("Cliente8"));
        
        //Imprime todas las cuentas
        for (Cuenta cuenta : cuentas) {
            System.out.println(cuenta.toString());
        }
        
        System.out.println("\n");
        
        //Numeros de Cuenta: get y set
        int i = 0;
        for (Cuenta cuenta : cuentas) {
            System.out.println("Cuenta número: " + cuenta.getNumCuenta());
            cuenta.setNumCuenta(i);
            System.out.println("Ahora es cuenta número: " + cuenta.getNumCuenta());
            i++;
        }
        
        System.out.println("\n");
        
        //Nombre del Cliente: get y set
        i=0;
        for (Cuenta cuenta : cuentas) {
            System.out.println("Cliente: " + cuenta.getCliente());
            cuenta.setCliente("Cliente" + i);
            System.out.println("Ahora es cliente: " + cuenta.getCliente());
            i++;
        }
        
        System.out.println("\n");
        
        //Saldo: get y set
        i=0;
        for (Cuenta cuenta : cuentas) {
            System.out.println("Saldo del cliente" + i + ": " + cuenta.getSaldo());
            cuenta.setSaldo(i*1000);
            System.out.println("Ahora es: " + cuenta.getSaldo());
            i++;
        }
        
        System.out.println("\n");
        
        //Fecha de creacion: get
        i=0;
        for (Cuenta cuenta : cuentas) {
            System.out.println("Fecha de creacion del cliente" + i + ": "
                    + cuenta.getFechaCreacion());
            i++;
        }
        
        System.out.println("\n");
        
        //Depositar
        i=0;
        try {
            //Deposito positivo
            System.out.println("Saldo actual del cliente" + i + ": " +
                    cuentas.get(i).getSaldo());
            System.out.println("Al cliente" + i + " se le van a depositar: "
                    + 500);
            cuentas.get(i).depositar(500);
            //Deposito negativo
            System.out.println("Saldo actual del cliente" + i + ": " +
                    cuentas.get(i).getSaldo());
            System.out.println("Al cliente" + i + " se le van a depositar: "
                    + (-500));
            cuentas.get(i).depositar((-500));
            System.out.println("Saldo actual del cliente" + i + ": " +
                    cuentas.get(i).getSaldo());
        }
        catch (Exception ex) {
            Logger.getLogger(ErickaCespedesTarea2.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Monto ingresado negativo.");
            System.out.println("Saldo actual del cliente" + i + ": " +
                    cuentas.get(i).getSaldo());
        }
        
        System.out.println("\n");
        
        //Retirar
        try {
            System.out.println("Saldo actual del cliente" + i + ": " +
                    cuentas.get(i).getSaldo());
            //Retiro positivo
            System.out.println("Al cliente" + i + " se le van a retirar: "
                    + 100);
            cuentas.get(i).retirar(100);
            System.out.println("Saldo actual del cliente" + i + ": " +
                    cuentas.get(i).getSaldo());
            //Retiro negativo
            System.out.println("Al cliente" + i + " se le van a retirar: "
                    + (-100));
            cuentas.get(i).retirar((-100));
            System.out.println("Saldo actual del cliente" + i + ": " +
                    cuentas.get(i).getSaldo());
        }
        catch (Exception ex) {
            Logger.getLogger(ErickaCespedesTarea2.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Monto ingresado negativo.");
            System.out.println("Saldo actual del cliente" + i + ": " +
                    cuentas.get(i).getSaldo());
        }
        
        System.out.println("\n");
        
        //toString()
        for (Cuenta cuenta : cuentas) {
            System.out.println(cuenta.toString());
        }
    }
    
}
