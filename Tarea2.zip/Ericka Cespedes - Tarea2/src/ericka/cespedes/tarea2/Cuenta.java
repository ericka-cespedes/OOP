/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ericka.cespedes.tarea2;

import java.time.LocalDateTime;

/**
 *
 * @author ericka
 */

/*Crear una clase llamada Cuenta que representa una cuenta de ahorros
perteneciente a una persona.
Cada cuenta tiene un número, cliente dueño, saldo y fecha de creación.*/

public class Cuenta {
    private static int cantCuentas = 0;
    // Atributo estatico
    
    private int numCuenta;
    /*El número de cuenta debe asignarse automáticamente, de forma que la
    primera cuenta que se crea será la 1, la segunda 2, y así sucesivamente. */
    // Se inicializa automaticamente segun cantCuentas
    private String cliente;
    private double saldo;
    private LocalDateTime fechaCreacion;
    // Se inicializa automaticamente segun cantCuentas
    
    //Constructores
    public Cuenta(String cliente) {
        /*Recibe el nombre del cliente por parámetro.
        numCuenta y fechaCreacion se inicializan autom. segun cantCuentas
        saldo se inicializa con el valor cero*/
        this.cliente = cliente;
        saldo = 0;
        cantCuentas++;
        numCuenta = cantCuentas;
        fechaCreacion = LocalDateTime.now();
        
    }
    public Cuenta(String cliente, double saldo) {
        /*  Recibe el nombre del cliente por parámetro.
        numCuenta y fechaCreacion se inicializan autom. segun cantCuentas
        saldo que tendrá la nueva cuenta        */
        this.cliente = cliente;
        this.saldo = saldo;
        cantCuentas++;
        numCuenta = cantCuentas;
        fechaCreacion = LocalDateTime.now();
    }
    
    public int getNumCuenta() {
        return numCuenta;
    }
    public void setNumCuenta(int numCuenta) {
        this.numCuenta = numCuenta;
    }
    
    public String getCliente() {
        return cliente;
    }
    public void setCliente(String cliente) {
        this.cliente = cliente;
    }
    
    public double getSaldo() {
        return saldo;
    }
    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    public LocalDateTime getFechaCreacion() {
        return fechaCreacion;
    }
    
    public void depositar(double monto) throws Exception {
        /*
        El método depositar debe aumentar el saldo en una cantidad determinada
        por medio de un parámetro.
        Restricciones: el monto a depositar debe ser positivo.
        Si no lo es, utilice throw new Exception("El monto a retirar no puede ser negativo.");
        */
        if (monto>=0) {
            saldo += monto;
        }
        else {
            throw new Exception("El monto a retirar no puede ser negativo." + "\n" +
                    "Monto ingresado: " + monto);
        }
    }
    
    public void retirar(double monto) throws Exception {
        /*
        Disminuye el saldo de la cuenta en lugar de aumentarlo.
        Determine las restricciones que deben cumplir ambos metodos e
        implemente la verificacion usando throw Exception
        Restricciones: el monto a retirar debe ser positivo.
        */
        if (monto>=0) {
            saldo -= monto;
        }
        else {
            throw new Exception("El monto a retirar no puede ser negativo." + "\n" +
                    "Monto ingresado: " + monto);
        }
    }
    
    public String toString() {
        String resultado = "Cuenta número: " + numCuenta + "\n";
        resultado += "Cliente: " + cliente + "\n";
        resultado += "Saldo: " + saldo + "\n";
        resultado += "Fecha creación: " + fechaCreacion + "\n";
        return resultado;
    }
}
