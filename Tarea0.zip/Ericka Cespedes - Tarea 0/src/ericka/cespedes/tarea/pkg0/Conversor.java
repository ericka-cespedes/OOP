/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ericka.cespedes.tarea.pkg0;

/**
 *
 * @author ericka
 */

/*Conversión de bases
Convertir un número escrito en una base indicada por el usuario a
otra base también indicada por el usuario
1 - El usuario ingresa la base en la que se encuentra el número original
2 - Ingresa el número que desea convertir
3 - Ingresa la base a la que desea convertir el número
**Debe verificarse que el número ingresado sea válido en la
base indicada.**
Entradas: int base, string número (hexadecimal), int base
Restricciones: Debe aceptar bases entre 2 y 20 solamente.
Salidas: int número en nueva base
*/

import java.util.Scanner;

public class Conversor {
    public static void conversor(String[] args) {
        //Input
        Scanner input = new Scanner(System.in);
        
        System.out.println("Ingrese el numero a convertir");
        String numero = input.nextLine();
        System.out.println("Ingrese la base del numero");
        int fromBase = input.nextInt();
        
        //Validacion de la base original del numero
        while (fromBase<2 || fromBase>20) {
            System.out.println("Numero invalido");
            System.out.println("Ingrese la base del numero");
            fromBase = input.nextInt();
        }
        
        System.out.println("Ingrese la base a la que desea convertir el numero");
        int toBase = input.nextInt();
        
        //Validacion de la base nueva del numero
        while (toBase<2 || toBase>20) {
            System.out.println("Numero invalido");
            System.out.println("Ingrese la base a la que desea convertir el numero");
            toBase = input.nextInt();
        }
        //Salida
        //resultado = Integer.toString(Integer.parseInt(numero, fromBase), toBase);
        System.out.println("El numero " + numero + " de base " + fromBase +
                " en base " + toBase + " es " +
                Integer.toString(Integer.parseInt(numero, fromBase), toBase));
    }
}
