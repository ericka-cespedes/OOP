/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//Main()

package ericka.cespedes.tarea.pkg0;

/**
 *
 * @author ericka
 */

import java.util.Scanner;

public class ErickaCespedesTarea0 {
    public static void main(String args[]) {
        OUTER:
        //Game Loop
        while (true) {
            System.out.println("Elija una opcion: ");
            System.out.println("(1) Ejercicio 1. Verificar anagramas");
            System.out.println("(2) Ejercicio 2. Codificador de malespin");
            System.out.println("(3) Ejercicio 3. Simulador de dados");
            System.out.println("(4) Ejercicio 4. Conversion de bases");
            System.out.println("(5) Salir");
            //Input
            Scanner input = new Scanner(System.in);
            int opcion = input.nextInt();
            //Opciones
            switch (opcion) {
                //Salir
                case 5:
                    break OUTER;
                //Ejercicio 1
                case 1:
                    Anagrama.anagrama(args);
                    break;
                //Ejercicio 2
                case 2:
                    Codificador.codificador(args);
                    break;
                //Ejercicio 3
                case 3:
                    Dado.dado(args);
                    break;
                //Ejercicio 4
                case 4:
                    Conversor.conversor(args);
                    break;
                //Entrada no valida
                default:
                    System.out.println("Entrada no valida. Ingresar un numero del 1 al 5.");
            }
        }
    }
}