/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ericka.cespedes.tarea.pkg0;

/*Verificar Anagramas
Se ignoran los espacios, signos de puntuacion y diferencias entre mayusculas
y minusculas.
Entradas: 2 strings
Salidas: Verdadero o Falso
*/

import java.util.Scanner;
import java.util.Arrays;

/**
 *
 * @author ericka
 */
public class Anagrama {
    public static void anagrama(String args[]) {
        //Inputs
        String string1;
        String string2;
        
        Scanner input = new Scanner(System.in);

        System.out.println("Ingrese la primer frase a comparar");
        string1 = input.nextLine();
        System.out.println("Ingrese la segunda frase a comparar");
        string2 = input.nextLine();
        
        //Poner todos los caracteres en minusculas
        //Remover espacios y signos de puntuacion de los strings
        string1 = string1.toLowerCase().replaceAll("[\\s]", "").replaceAll("[\\W]", "");
        string2 = string2.toLowerCase().replaceAll("[\\s]", "").replaceAll("[\\W]", "");
        
        //Hace un array con los caracteres de cada palabra
        char[] s1 = string1.toCharArray();
        char[] s2 = string2.toCharArray();
        
        //Ordena los caracteres
        Arrays.sort(s1);
        Arrays.sort(s2);
        
        //Compara los arrays
        System.out.println(Arrays.equals(s1, s2));
    }
}