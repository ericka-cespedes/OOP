/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ericka.cespedes.tarea.pkg0;

/**
 *
 * @author ericka
 */

/*Codificador de malespín
Intercambia A <-> E, B <-> T, F <-> G, I <-> O, M <-> P
Entradas: String a codificar
Salidas: String codificado
*/

import java.util.Scanner;

public class Codificador {
    public static void codificador(String args[]) {
        //Declaracion de variables
        String string;
        String stringNuevo = "";
        //Input
        Scanner input = new Scanner(System.in);

        System.out.println("Ingrese el texto a codificar");
        string = input.nextLine();
        
        //Loop que crea un nuevo String al hacer los cambios del viejo
        for (int i=0; i < string.length(); i++) {
            switch(string.charAt(i)) {
                //A<->E
                case 'a': {
                    stringNuevo = stringNuevo.concat("e");
                    break;
                }
                case 'A': {
                    stringNuevo = stringNuevo.concat("E");
                    break;
                }
                case 'e': {
                    stringNuevo = stringNuevo.concat("a");
                    break;
                }
                case 'E': {
                    stringNuevo = stringNuevo.concat("A");
                    break;
                }
                //B<->T
                case 'b': {
                    stringNuevo = stringNuevo.concat("t");
                    break;
                }
                case 'B': {
                    stringNuevo = stringNuevo.concat("T");
                    break;
                }
                case 't': {
                    stringNuevo = stringNuevo.concat("b");
                    break;
                }
                case 'T': {
                    stringNuevo = stringNuevo.concat("B");
                    break;
                }
                //F<->G
                case 'f': {
                    stringNuevo = stringNuevo.concat("g");
                    break;
                }
                case 'F': {
                    stringNuevo = stringNuevo.concat("G");
                    break;
                }
                case 'g': {
                    stringNuevo = stringNuevo.concat("f");
                    break;
                }
                case 'G': {
                    stringNuevo = stringNuevo.concat("F");
                    break;
                }
                //I<->O
                case 'i': {
                    stringNuevo = stringNuevo.concat("o");
                    break;
                }
                case 'I': {
                    stringNuevo = stringNuevo.concat("O");
                    break;
                }
                case 'o': {
                    stringNuevo = stringNuevo.concat("i");
                    break;
                }
                case 'O': {
                    stringNuevo = stringNuevo.concat("I");
                    break;
                }
                //M<->P
                case 'm': {
                    stringNuevo = stringNuevo.concat("p");
                    break;
                }
                case 'M': {
                    stringNuevo = stringNuevo.concat("P");
                    break;
                }
                case 'p': {
                    stringNuevo = stringNuevo.concat("m");
                    break;
                }
                case 'P': {
                    stringNuevo = stringNuevo.concat("M");
                    break;
                }
                default: stringNuevo = stringNuevo.concat(Character.toString(string.charAt(i)));
            }
        
        }
        //Salida
	System.out.println("El texto era: " + string);
	System.out.println("Texto codificado: " + stringNuevo);
    }
}
