/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ericka.cespedes.tarea.pkg0;

/**
 *
 * @author ericka
 */

/*Simulador de dados
Lanzamiento de dados de 4, 6, 8, 10, 12 y 20 lados
1 - Cuántos dados desea lanzar (No tiene límite)
2 - Cantidad de lados que quiere en cada uno de los dados
Entradas: int cantidad de dados, int cantidad de lados
    Restricciones: cantidad de dados no puede ser negativa o igual a 0
                    4, 6, 8, 10, 12 y 20 lados
Salidas: resultado de los dados lanzados
*/

import java.util.Scanner;
import java.util.Random;

public class Dado {
    public static void dado(String args[]) {
    //Declaracion de variables
    int dados;
    int lados;
    String res = "";
    
    //Random e Input
    Random r = new Random();
    Scanner input = new Scanner(System.in);
    
    //Input de la cantidad de dados
    System.out.println("Ingrese la cantidad de dados que desea lanzar");
    dados = input.nextInt();
    
    //Validacion de que la cantidad de dados sea mayor a 0
    while (dados<1) {
        System.out.println("Numero invalido");
        System.out.println("Ingrese la cantidad de dados que desea lanzar");
        dados = input.nextInt();
    }
    
    //Loop para el numero de lados por la cantidad de datos
    for (int i = 1; i <= dados; i++) {
        
        //Input del numero de lados
        System.out.println("Ingrese la cantidad de lados que quiere en el dado #" + i);
        lados = input.nextInt();
        
        //Validacion para el numero de lados
        while (lados!=4 && lados!=6 && lados!=8 && lados!=10 && lados!=12 && lados!=20) {
            System.out.println("Numero invalido");
            System.out.println("Ingrese la cantidad de lados que quiere en el dado #" + i);
            lados = input.nextInt();
        }
        
        //Resultado del dado
        int resultado = r.nextInt(lados) +1; // 1 a lados
        
        //Suma los resultados de cada dado
        res += "El resultado del dado #" + i + " de " + lados + " lados es " +
                resultado + "." + System.lineSeparator();
        
        }
    //Salida
    System.out.println(res);
    }
}
